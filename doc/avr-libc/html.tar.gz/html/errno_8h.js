var errno_8h =
[
    [ "EDOM", "group__avr__errno.html#ga5fe247e079b591a68e0fdbf7caec5b70", null ],
    [ "ERANGE", "group__avr__errno.html#gaa1591a4f3a86360108de5b9ba34980ca", null ],
    [ "errno", "group__avr__errno.html#gad65a8842cc674e3ddf69355898c0ecbf", null ]
];