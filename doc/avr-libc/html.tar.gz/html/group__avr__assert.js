var group__avr__assert =
[
    [ "assert", "group__avr__assert.html#ga0041af519e0e7d47c9bcc83760c4669e", null ]
];