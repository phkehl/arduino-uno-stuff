var group__avr__cpufunc =
[
    [ "_MemoryBarrier", "group__avr__cpufunc.html#ga1060ab52075a71b61c88636e204321b2", null ],
    [ "_NOP", "group__avr__cpufunc.html#ga46388d9db8422abfea56ae2323f7a77c", null ]
];