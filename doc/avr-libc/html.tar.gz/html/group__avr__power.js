var group__avr__power =
[
    [ "clock_prescale_set", "group__avr__power.html#gae2d32c0c4f18f0019e680354bcc1c3ef", null ]
];