var group__avr__sfr =
[
    [ "Additional notes from <avr/sfr_defs.h>", "group__avr__sfr__notes.html", null ],
    [ "_BV", "group__avr__sfr.html#ga11643f271076024c395a93800b3d9546", null ],
    [ "bit_is_clear", "group__avr__sfr.html#gad188fb0fbfd923bdb01294072367d024", null ],
    [ "bit_is_set", "group__avr__sfr.html#ga3b034cb1d74b9addc7599bd6ea6bd0d9", null ],
    [ "loop_until_bit_is_clear", "group__avr__sfr.html#gabf06c3d703cf5adc691c0be5d72e7839", null ],
    [ "loop_until_bit_is_set", "group__avr__sfr.html#gaaf6857fa882da35f8685e2001e5c3bbe", null ]
];