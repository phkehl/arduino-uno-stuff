var group__avr__sleep =
[
    [ "sleep_bod_disable", "group__avr__sleep.html#gabf889562cc5ea768ee80cfc8a5bb0312", null ],
    [ "sleep_cpu", "group__avr__sleep.html#ga157b2578d95309c197b739f812938d94", null ],
    [ "sleep_disable", "group__avr__sleep.html#gaeae22433a78fd8d50f915fb68c416efd", null ],
    [ "sleep_enable", "group__avr__sleep.html#ga475174a7aa4eda03dfa7a4483e400a9e", null ],
    [ "sleep_mode", "group__avr__sleep.html#ga3775b21f297187752bcfc434a541209a", null ]
];