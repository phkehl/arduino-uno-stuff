var group__avr__sleep =
[
    [ "sleep_cpu", "group__avr__sleep.html#ga157b2578d95309c197b739f812938d94", null ],
    [ "sleep_disable", "group__avr__sleep.html#gaeae22433a78fd8d50f915fb68c416efd", null ],
    [ "sleep_enable", "group__avr__sleep.html#ga475174a7aa4eda03dfa7a4483e400a9e", null ]
];