var group__demos =
[
    [ "Combining C and assembly source files", "group__asmdemo.html", null ],
    [ "A simple project", "group__demo__project.html", null ],
    [ "A more sophisticated project", "group__largedemo.html", null ],
    [ "Using the standard IO facilities", "group__stdiodemo.html", null ],
    [ "Example using the two-wire interface (TWI)", "group__twi__demo.html", null ]
];