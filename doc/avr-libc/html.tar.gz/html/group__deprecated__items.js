var group__deprecated__items =
[
    [ "cbi", "group__deprecated__items.html#ga08ee265dc07048dbb5a8b6c84551d520", null ],
    [ "enable_external_int", "group__deprecated__items.html#ga9a3fe82a7199e9e84f7be6a5f23127bc", null ],
    [ "inb", "group__deprecated__items.html#gad6488a48837d179b1833e2f48dac9665", null ],
    [ "inp", "group__deprecated__items.html#ga5cfa4750a0633c34c7a361d8fd62c042", null ],
    [ "INTERRUPT", "group__deprecated__items.html#gaa0b2d3a87492967c01615f32f30d06d5", null ],
    [ "outb", "group__deprecated__items.html#ga3a3b4c1ddf0c05701f933d70de330f08", null ],
    [ "outp", "group__deprecated__items.html#gaab324bd721e821e275f00c3478e240c9", null ],
    [ "sbi", "group__deprecated__items.html#ga014ef751e83f97569c06f3cdd888f3f7", null ],
    [ "timer_enable_int", "group__deprecated__items.html#ga46f0b87ccc2ab63dea1ff28207270b82", null ]
];