var group__util__delay__basic =
[
    [ "_delay_loop_1", "group__util__delay__basic.html#ga4e3957917c4c447d0f9166dac881b4e3", null ],
    [ "_delay_loop_2", "group__util__delay__basic.html#ga74a94fec42bac9f1ff31fd443d419a6a", null ]
];