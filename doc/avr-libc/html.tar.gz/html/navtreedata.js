var NAVTREE =
[
  [ "avr-libc", "index.html", [
    [ "AVR Libc", "index.html", [
      [ "Introduction", "index.html#avr_libc_intro", null ],
      [ "General information about this library", "index.html#avr_libc_general", null ],
      [ "Supported Devices", "index.html#supp_devices", null ],
      [ "avr-libc License", "index.html#license", null ]
    ] ],
    [ "Toolchain Overview", "overview.html", [
      [ "Introduction", "overview.html#overview_introduction", null ],
      [ "FSF and GNU", "overview.html#overview_fsf_and_gnu", null ],
      [ "GCC", "overview.html#overview_gcc", null ],
      [ "GNU Binutils", "overview.html#overview_binutils", null ],
      [ "avr-libc", "overview.html#overview_avr-libc", null ],
      [ "Building Software", "overview.html#overview_building_software", null ],
      [ "AVRDUDE", "overview.html#overview_avrdude", null ],
      [ "GDB / Insight / DDD", "overview.html#overview_gdb_insight_ddd", null ],
      [ "AVaRICE", "overview.html#overview_avarice", null ],
      [ "SimulAVR", "overview.html#overview_simulavr", null ],
      [ "Utilities", "overview.html#overview_utilities", null ],
      [ "Toolchain Distributions (Distros)", "overview.html#overview_distros", null ],
      [ "Open Source", "overview.html#overview_open_source", null ]
    ] ],
    [ "Memory Areas and Using malloc()", "malloc.html", [
      [ "Introduction", "malloc.html#malloc_intro", null ],
      [ "Internal vs. external RAM", "malloc.html#malloc_where", null ],
      [ "Tunables for malloc()", "malloc.html#malloc_tunables", null ],
      [ "Implementation details", "malloc.html#malloc_impl", null ]
    ] ],
    [ "Memory Sections", "mem_sections.html", [
      [ "The .text Section", "mem_sections.html#sec_dot_text", null ],
      [ "The .data Section", "mem_sections.html#sec_dot_data", null ],
      [ "The .bss Section", "mem_sections.html#sec_dot_bss", null ],
      [ "The .eeprom Section", "mem_sections.html#sec_dot_eeprom", null ],
      [ "The .noinit Section", "mem_sections.html#sec_dot_noinit", null ],
      [ "The .initN Sections", "mem_sections.html#sec_dot_init", null ],
      [ "The .finiN Sections", "mem_sections.html#sec_dot_fini", null ],
      [ "The .note.gnu.avr.deviceinfo Section", "mem_sections.html#sec_dot_note", null ],
      [ "Using Sections in Assembler Code", "mem_sections.html#asm_sections", null ],
      [ "Using Sections in C Code", "mem_sections.html#c_sections", null ]
    ] ],
    [ "Data in Program Space", "pgmspace.html", [
      [ "Introduction", "pgmspace.html#pgmspace_introduction", null ],
      [ "A Note On const", "pgmspace.html#pgmspace_const", null ],
      [ "Storing and Retrieving Data in the Program Space", "pgmspace.html#pgmspace_data", null ],
      [ "Storing and Retrieving Strings in the Program Space", "pgmspace.html#pgmspace_strings", null ],
      [ "Caveats", "pgmspace.html#pgmspace_caveats", null ]
    ] ],
    [ "avr-libc and assembler programs", "assembler.html", [
      [ "Introduction", "assembler.html#ass_intro", null ],
      [ "Invoking the compiler", "assembler.html#ass_tools", null ],
      [ "Example program", "assembler.html#ass_example", null ],
      [ "Pseudo-ops and operators", "assembler.html#ass_pseudoops", null ]
    ] ],
    [ "Inline Assembler Cookbook", "inline_asm.html", [
      [ "GCC asm Statement", "inline_asm.html#gcc_asm", null ],
      [ "Assembler Code", "inline_asm.html#asm_code", null ],
      [ "Input and Output Operands", "inline_asm.html#io_ops", null ],
      [ "Clobbers", "inline_asm.html#clobbers", null ],
      [ "Assembler Macros", "inline_asm.html#asm_macros", null ],
      [ "C Stub Functions", "inline_asm.html#asm_c_stubs", null ],
      [ "C Names Used in Assembler Code", "inline_asm.html#c_names_in_asm", null ],
      [ "Links", "inline_asm.html#links", null ]
    ] ],
    [ "How to Build a Library", "library.html", [
      [ "Introduction", "library.html#library_intro", null ],
      [ "How the Linker Works", "library.html#library_linker", null ],
      [ "How to Design a Library", "library.html#library_design", null ],
      [ "Creating a Library", "library.html#library_creating", null ],
      [ "Using a Library", "library.html#library_using", null ]
    ] ],
    [ "Benchmarks", "benchmarks.html", [
      [ "A few of libc functions.", "benchmarks.html#bench_libc", null ],
      [ "Math functions.", "benchmarks.html#bench_libm", null ]
    ] ],
    [ "Porting From IAR to AVR GCC", "porting.html", [
      [ "Introduction", "porting.html#iar_porting_intro", null ],
      [ "Registers", "porting.html#iar_porting_register", null ],
      [ "Interrupt Service Routines (ISRs)", "porting.html#iar_porting_isr", null ],
      [ "Intrinsic Routines", "porting.html#iar_porting_intrinsic", null ],
      [ "Flash Variables", "porting.html#iar_porting_flash", null ],
      [ "Non-Returning main()", "porting.html#iar_porting_non_returning_main", null ],
      [ "Locking Registers", "porting.html#iar_porting_locking", null ]
    ] ],
    [ "Frequently Asked Questions", "FAQ.html", [
      [ "FAQ Index", "FAQ.html#faq_index", null ],
      [ "My program doesn't recognize a variable updated within an interrupt routine", "FAQ.html#faq_volatile", null ],
      [ "I get \"undefined reference to...\" for functions like \"sin()\"", "FAQ.html#faq_libm", null ],
      [ "How to permanently bind a variable to a register?", "FAQ.html#faq_regbind", null ],
      [ "How to modify MCUCR or WDTCR early?", "FAQ.html#faq_startup", null ],
      [ "What is all this _BV() stuff about?", "FAQ.html#faq_use_bv", null ],
      [ "Can I use C++ on the AVR?", "FAQ.html#faq_cplusplus", null ],
      [ "Shouldn't I initialize all my variables?", "FAQ.html#faq_varinit", null ],
      [ "Why do some 16-bit timer registers sometimes get trashed?", "FAQ.html#faq_16bitio", null ],
      [ "How do I use a #define'd constant in an asm statement?", "FAQ.html#faq_asmconst", null ],
      [ "Why does the PC randomly jump around when single-stepping through my program in avr-gdb?", "FAQ.html#faq_gdboptimize", null ],
      [ "How do I trace an assembler file in avr-gdb?", "FAQ.html#faq_asmstabs", null ],
      [ "How do I pass an IO port as a parameter to a function?", "FAQ.html#faq_port_pass", null ],
      [ "What registers are used by the C compiler?", "FAQ.html#faq_reg_usage", null ],
      [ "How do I put an array of strings completely in ROM?", "FAQ.html#faq_rom_array", null ],
      [ "How to use external RAM?", "FAQ.html#faq_ext_ram", null ],
      [ "Which -O flag to use?", "FAQ.html#faq_optflags", null ],
      [ "How do I relocate code to a fixed address?", "FAQ.html#faq_reloc_code", null ],
      [ "My UART is generating nonsense!  My ATmega128 keeps crashing! Port F is completely broken!", "FAQ.html#faq_fuses", null ],
      [ "Why do all my \"foo...bar\" strings eat up the SRAM?", "FAQ.html#faq_flashstrings", null ],
      [ "Why does the compiler compile an 8-bit operation that uses bitwise operators into a 16-bit operation in assembly?", "FAQ.html#faq_intpromote", null ],
      [ "How to detect RAM memory and variable overlap problems?", "FAQ.html#faq_ramoverlap", null ],
      [ "Is it really impossible to program the ATtinyXX in C?", "FAQ.html#faq_tinyavr_c", null ],
      [ "What is this \"clock skew detected\" message?", "FAQ.html#faq_clockskew", null ],
      [ "Why are (many) interrupt flags cleared by writing a logical 1?", "FAQ.html#faq_intbits", null ],
      [ "Why have \"programmed\" fuses the bit value 0?", "FAQ.html#faq_fuselow", null ],
      [ "Which AVR-specific assembler operators are available?", "FAQ.html#faq_asmops", null ],
      [ "Why are interrupts re-enabled in the middle of writing the stack pointer?", "FAQ.html#faq_spman", null ],
      [ "Why are there five different linker scripts?", "FAQ.html#faq_linkerscripts", null ],
      [ "How to add a raw binary image to linker output?", "FAQ.html#faq_binarydata", null ],
      [ "How do I perform a software reset of the AVR?", "FAQ.html#faq_softreset", null ],
      [ "I am using floating point math. Why is the compiled code so big? Why does my code not work?", "FAQ.html#faq_math", null ],
      [ "What pitfalls exist when writing reentrant code?", "FAQ.html#faq_reentrant", null ],
      [ "Why are some addresses of the EEPROM corrupted (usually address zero)?", "FAQ.html#faq_eeprom_corruption", null ],
      [ "Why is my baud rate wrong?", "FAQ.html#faq_wrong_baud_rate", null ],
      [ "On a device with more than 128 KiB of flash, how to make function pointers work?", "FAQ.html#faq_funcptr_gt128kib", null ],
      [ "Why is assigning ports in a \"chain\" a bad idea?", "FAQ.html#faq_assign_chain", null ]
    ] ],
    [ "Building and Installing the GNU Tool Chain", "install_tools.html", [
      [ "Building and Installing under Linux, FreeBSD, and Others", "install_tools.html#install_unix", null ],
      [ "Required Tools", "install_tools.html#required_tools", null ],
      [ "Optional Tools", "install_tools.html#optional_tools", null ],
      [ "GNU Binutils for the AVR target", "install_tools.html#install_avr_binutils", null ],
      [ "GCC for the AVR target", "install_tools.html#install_avr_gcc", null ],
      [ "AVR LibC", "install_tools.html#install_avr_libc", null ],
      [ "AVRDUDE", "install_tools.html#install_avrprog", null ],
      [ "GDB for the AVR target", "install_tools.html#install_gdb", null ],
      [ "SimulAVR", "install_tools.html#install_simulavr", null ],
      [ "AVaRICE", "install_tools.html#install_avarice", null ],
      [ "Building and Installing under Windows", "install_tools.html#install_windows", null ],
      [ "Tools Required for Building the Toolchain for Windows", "install_tools.html#install_windows_tools", null ],
      [ "Building the Toolchain for Windows", "install_tools.html#install_windows_building", null ]
    ] ],
    [ "Using the GNU tools", "using_tools.html", [
      [ "Options for the C compiler avr-gcc", "using_tools.html#using_avr_gcc", [
        [ "Machine-specific options for the AVR", "using_tools.html#using_avr_gcc_mach_opt", null ],
        [ "Selected general compiler options", "using_tools.html#using_sel_gcc_opts", null ]
      ] ],
      [ "Options for the assembler avr-as", "using_tools.html#using_avr_as", [
        [ "Machine-specific assembler options", "using_tools.html#using_avr_as_mach_opts", null ],
        [ "Examples for assembler options passed through the C compiler", "using_tools.html#using_avr_example", null ]
      ] ],
      [ "Controlling the linker avr-ld", "using_tools.html#using_avr_ld", [
        [ "Selected linker options", "using_tools.html#using_sel_ld_opts", null ],
        [ "Passing linker options from the C compiler", "using_tools.html#using_pass_ld_opts", null ]
      ] ]
    ] ],
    [ "Compiler optimization", "optimization.html", [
      [ "Problems with reordering code", "optimization.html#optim_code_reorder", null ]
    ] ],
    [ "Using the avrdude program", "using_avrprog.html", null ],
    [ "Release Numbering and Methodology", "release_method.html", [
      [ "Release Version Numbering Scheme", "release_method.html#version_info", null ],
      [ "Releasing AVR Libc", "release_method.html#release_info", [
        [ "Creating an SVN branch", "release_method.html#release_branch", null ],
        [ "Making a release", "release_method.html#release_rolling", null ]
      ] ]
    ] ],
    [ "Acknowledgments", "acks.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"FAQ.html",
"group__avr__boot.html#ga8d2baaca2991318e0b06fdf9a5264923",
"group__avr__inttypes.html#gab153efc9e6547ca56f42de767cde2595",
"group__avr__pgmspace.html#ga05ca900ebf7cd121be73c654d9ccb3eb",
"group__avr__stdint.html#ga831d6234342279926bb11bad3a37add9",
"group__avr__stdlib.html#ga63e28bec3592384b44606f011634c5a8",
"group__setjmp.html",
"overview.html#overview_gcc",
"vprintf_8c_source.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';