var searchData=
[
  ['rand',['rand',['../group__avr__stdlib.html#gae23144bcbb8e3742b00eb687c36654d1',1,'rand(void):&#160;rand.c'],['../group__avr__stdlib.html#gae23144bcbb8e3742b00eb687c36654d1',1,'rand(void):&#160;rand.c']]],
  ['rand_5fmax',['RAND_MAX',['../group__avr__stdlib.html#ga690f251553b39fd4f31894826141b61a',1,'stdlib.h']]],
  ['rand_5fr',['rand_r',['../group__avr__stdlib.html#gaf5085001be836a0f2a5d3269a7c9fd04',1,'rand_r(unsigned long *__ctx):&#160;rand.c'],['../group__avr__stdlib.html#gaf5085001be836a0f2a5d3269a7c9fd04',1,'rand_r(unsigned long *ctx):&#160;rand.c']]],
  ['random',['random',['../group__avr__stdlib.html#ga114aeb1751119382aaf3340355b22cfd',1,'random(void):&#160;random.c'],['../group__avr__stdlib.html#ga114aeb1751119382aaf3340355b22cfd',1,'random(void):&#160;random.c']]],
  ['random_5fmax',['RANDOM_MAX',['../group__avr__stdlib.html#ga3bd31f0d9a9127548b734e7ca03cc6df',1,'stdlib.h']]],
  ['random_5fr',['random_r',['../group__avr__stdlib.html#gaa99a0733f06d2b9960a1401c2721af1e',1,'random_r(unsigned long *__ctx):&#160;random.c'],['../group__avr__stdlib.html#gaa99a0733f06d2b9960a1401c2721af1e',1,'random_r(unsigned long *ctx):&#160;random.c']]],
  ['realloc',['realloc',['../group__avr__stdlib.html#gafd300bad8b4dd2e88b07d464d76c92aa',1,'realloc(void *__ptr, size_t __size) __ATTR_MALLOC__:&#160;realloc.c'],['../group__avr__stdlib.html#gafd300bad8b4dd2e88b07d464d76c92aa',1,'realloc(void *ptr, size_t len):&#160;realloc.c']]],
  ['release_20numbering_20and_20methodology',['Release Numbering and Methodology',['../release_method.html',1,'']]],
  ['rem',['rem',['../structdiv__t.html#ac64389de252de53eda8b4f8dbb7c623f',1,'div_t::rem()'],['../structldiv__t.html#a0f217ff62b8640aa945ec84d6d0bd000',1,'ldiv_t::rem()']]],
  ['reti',['reti',['../group__avr__interrupts.html#ga3b991e8168db8fc866e31f9a6d10533b',1,'interrupt.h']]],
  ['round',['round',['../group__avr__math.html#ga6eb04604d801054c5a2afe195d1dd75d',1,'math.h']]],
  ['roundf',['roundf',['../group__avr__math.html#gac6950642117c821388ec37e7b656a346',1,'math.h']]]
];
