var searchData=
[
  ['year',['year',['../structweek__date.html#a678eb6d982a51d7d398bbad118039850',1,'week_date']]]
];
