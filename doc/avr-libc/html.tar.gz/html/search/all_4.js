var searchData=
[
  ['day',['day',['../structweek__date.html#af5099315e3a2e5afb43701de953d712e',1,'week_date']]],
  ['daylight_5fseconds',['daylight_seconds',['../group__avr__time.html#ga71762e360eaab527a334d9114f68aa21',1,'daylight_seconds(const time_t *timer):&#160;daylight_seconds.c'],['../group__avr__time.html#ga71762e360eaab527a334d9114f68aa21',1,'daylight_seconds(const time_t *timer):&#160;daylight_seconds.c']]],
  ['delay_2eh',['delay.h',['../delay_8h.html',1,'']]],
  ['delay_5fbasic_2eh',['delay_basic.h',['../delay__basic_8h.html',1,'']]],
  ['demo_20projects',['Demo projects',['../group__demos.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['difftime',['difftime',['../group__avr__time.html#ga1732c46d47837951d399755899af5240',1,'difftime(time_t time1, time_t time0):&#160;difftime.c'],['../group__avr__time.html#ga1732c46d47837951d399755899af5240',1,'difftime(time_t t1, time_t t2):&#160;difftime.c']]],
  ['div',['div',['../group__avr__stdlib.html#ga7486ea9a8a90ac6b93bed37d08ebbd9e',1,'stdlib.h']]],
  ['div_5ft',['div_t',['../structdiv__t.html',1,'']]],
  ['dtostr_5falways_5fsign',['DTOSTR_ALWAYS_SIGN',['../group__avr__stdlib.html#ga815d0d26e215d9b78af1cb2288d22361',1,'stdlib.h']]],
  ['dtostr_5fplus_5fsign',['DTOSTR_PLUS_SIGN',['../group__avr__stdlib.html#ga268774f80047812307365f3113109767',1,'stdlib.h']]],
  ['dtostr_5fuppercase',['DTOSTR_UPPERCASE',['../group__avr__stdlib.html#ga125348f1e1fed1793426f4c4dc6fb2f7',1,'stdlib.h']]],
  ['dtostre',['dtostre',['../group__avr__stdlib.html#ga6c140bdd3b9bd740a1490137317caa44',1,'dtostre(double __val, char *__s, unsigned char __prec, unsigned char __flags):&#160;dtostre.c'],['../group__avr__stdlib.html#ga6c140bdd3b9bd740a1490137317caa44',1,'dtostre(double val, char *sbeg, unsigned char prec, unsigned char flags):&#160;dtostre.c']]],
  ['dtostrf',['dtostrf',['../group__avr__stdlib.html#ga060c998e77fb5fc0d3168b3ce8771d42',1,'dtostrf(double __val, signed char __width, unsigned char __prec, char *__s):&#160;dtostrf.c'],['../group__avr__stdlib.html#ga060c998e77fb5fc0d3168b3ce8771d42',1,'dtostrf(double val, signed char width, unsigned char prec, char *sout):&#160;dtostrf.c']]],
  ['data_20in_20program_20space',['Data in Program Space',['../pgmspace.html',1,'']]]
];
