var searchData=
[
  ['get_5fextended_5ffuse_5fbits',['GET_EXTENDED_FUSE_BITS',['../group__avr__boot.html#gaf08aabaebbd69da659357f402d4d28ce',1,'boot.h']]],
  ['get_5fhigh_5ffuse_5fbits',['GET_HIGH_FUSE_BITS',['../group__avr__boot.html#ga44e70c9662e7ac06484144c15bc69aea',1,'boot.h']]],
  ['get_5flock_5fbits',['GET_LOCK_BITS',['../group__avr__boot.html#gae12d288a22cfbfa9d0cde12b1a779bfe',1,'boot.h']]],
  ['get_5flow_5ffuse_5fbits',['GET_LOW_FUSE_BITS',['../group__avr__boot.html#gac68c37ecf2354ba2af6e08379d65899f',1,'boot.h']]],
  ['getc',['getc',['../group__avr__stdio.html#gacff255b3a0079ebb1516e8a4eb23a6fb',1,'stdio.h']]],
  ['getchar',['getchar',['../group__avr__stdio.html#gac0484b3e3a4d8361d91c3322440f9195',1,'stdio.h']]],
  ['gets',['gets',['../group__avr__stdio.html#gaf577dcba9afe50a9d068d0b69ac85d2f',1,'gets(char *__str):&#160;gets.c'],['../group__avr__stdio.html#gaf577dcba9afe50a9d068d0b69ac85d2f',1,'gets(char *str):&#160;gets.c']]],
  ['gm_5fsidereal',['gm_sidereal',['../group__avr__time.html#gaae725f7944578bf948bb5c44588b7b7c',1,'gm_sidereal(const time_t *timer):&#160;gm_sidereal.c'],['../group__avr__time.html#gaae725f7944578bf948bb5c44588b7b7c',1,'gm_sidereal(const time_t *timer):&#160;gm_sidereal.c']]],
  ['gmtime',['gmtime',['../group__avr__time.html#gae76343d6a51c93b9318ac0ced05225cd',1,'gmtime(const time_t *timer):&#160;gmtime.c'],['../group__avr__time.html#gae76343d6a51c93b9318ac0ced05225cd',1,'gmtime(const time_t *timeptr):&#160;gmtime.c']]],
  ['gmtime_5fr',['gmtime_r',['../group__avr__time.html#ga7cb461118a6aeebeaacd48ee127b952a',1,'gmtime_r(const time_t *timer, struct tm *timeptr):&#160;gmtime_r.c'],['../group__avr__time.html#ga7cb461118a6aeebeaacd48ee127b952a',1,'gmtime_r(const time_t *timer, struct tm *timeptr):&#160;gmtime_r.c']]]
];
