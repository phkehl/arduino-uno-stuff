var searchData=
[
  ['qsort',['qsort',['../group__avr__stdlib.html#gafd4bf2faec43342e7ad3d2ab37bac1fe',1,'stdlib.h']]],
  ['quot',['quot',['../structdiv__t.html#a0b9dda2884048daa68ca4aaa12b17b9a',1,'div_t::quot()'],['../structldiv__t.html#a73efd59c176304c327cb4214d0e5e5c9',1,'ldiv_t::quot()']]]
];
