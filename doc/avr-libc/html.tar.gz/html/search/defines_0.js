var searchData=
[
  ['clock_5fprescale_5fget',['clock_prescale_get',['../power_8h.html#a7154fa3046d3387af8d6c5f489bf7194',1,'power.h']]]
];
