var searchData=
[
  ['_5fmonths_5f',['_MONTHS_',['../group__avr__time.html#ga9ea260b185fe2c5bb23c64f5954c28aa',1,'time.h']]],
  ['_5fweek_5fdays_5f',['_WEEK_DAYS_',['../group__avr__time.html#gae6535271b8e2884a9ed9fe92ecfd87e1',1,'time.h']]]
];
