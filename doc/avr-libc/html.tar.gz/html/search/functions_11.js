var searchData=
[
  ['ultoa',['ultoa',['../group__avr__stdlib.html#ga34f41757388f40e340f31e370ac009b5',1,'stdlib.h']]],
  ['ungetc',['ungetc',['../group__avr__stdio.html#gab4f9b130166e5811519513d6178c1ae3',1,'ungetc(int __c, FILE *__stream):&#160;ungetc.c'],['../group__avr__stdio.html#gab4f9b130166e5811519513d6178c1ae3',1,'ungetc(int c, FILE *stream):&#160;ungetc.c']]],
  ['utoa',['utoa',['../group__avr__stdlib.html#gad50d835af7e358518fd100179732e948',1,'stdlib.h']]]
];
