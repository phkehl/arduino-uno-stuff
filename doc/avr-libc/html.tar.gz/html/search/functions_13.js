var searchData=
[
  ['week_5fof_5fmonth',['week_of_month',['../group__avr__time.html#ga53e37af6d547a0afa624fc2230c8db7a',1,'week_of_month(const struct tm *timeptr, uint8_t start):&#160;week_of_month.c'],['../group__avr__time.html#ga53e37af6d547a0afa624fc2230c8db7a',1,'week_of_month(const struct tm *timestruct, uint8_t base):&#160;week_of_month.c']]],
  ['week_5fof_5fyear',['week_of_year',['../group__avr__time.html#ga6e351ab03dbd6cb078dd48d1f40b9133',1,'week_of_year(const struct tm *timeptr, uint8_t start):&#160;week_of_year.c'],['../group__avr__time.html#ga6e351ab03dbd6cb078dd48d1f40b9133',1,'week_of_year(const struct tm *timestruct, uint8_t base):&#160;week_of_year.c']]]
];
