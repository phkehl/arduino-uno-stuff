var searchData=
[
  ['calloc',['calloc',['../group__avr__stdlib.html#ga51ac965dacbc9daf922f469bdcfe00c2',1,'calloc(size_t __nele, size_t __size) __ATTR_MALLOC__:&#160;calloc.c'],['../group__avr__stdlib.html#ga51ac965dacbc9daf922f469bdcfe00c2',1,'calloc(size_t nele, size_t size):&#160;calloc.c']]],
  ['cbrt',['cbrt',['../group__avr__math.html#ga9dff6efc5e63405ba23afb75eb3e4af0',1,'math.h']]],
  ['ceil',['ceil',['../group__avr__math.html#ga61470611f23ceef5d3e9cf63d84cd8a7',1,'math.h']]],
  ['clearerr',['clearerr',['../group__avr__stdio.html#gaaa6d255675688c736c99ebd32f2a7214',1,'clearerr(FILE *__stream):&#160;clearerr.c'],['../group__avr__stdio.html#gaaa6d255675688c736c99ebd32f2a7214',1,'clearerr(FILE *stream):&#160;clearerr.c']]],
  ['copysign',['copysign',['../group__avr__math.html#gaaebf29a8e50e6d8f88b6caf697021c86',1,'math.h']]],
  ['cos',['cos',['../group__avr__math.html#ga542f5e42e0d3b5df63de0e34ec06bb40',1,'math.h']]],
  ['cosh',['cosh',['../group__avr__math.html#ga2ec1caf3ba3b1ba62eccb3eddf029438',1,'math.h']]],
  ['ctime',['ctime',['../group__avr__time.html#ga72a5383fadfbaa033ac36e9e45b0bd6d',1,'ctime(const time_t *timer):&#160;ctime.c'],['../group__avr__time.html#ga72a5383fadfbaa033ac36e9e45b0bd6d',1,'ctime(const time_t *timeptr):&#160;ctime.c']]],
  ['ctime_5fr',['ctime_r',['../group__avr__time.html#ga34fa7766f6b0a8a74a41683693eabad9',1,'ctime_r(const time_t *timer, char *buf):&#160;ctime_r.c'],['../group__avr__time.html#ga34fa7766f6b0a8a74a41683693eabad9',1,'ctime_r(const time_t *timeptr, char *buffer):&#160;ctime_r.c']]]
];
