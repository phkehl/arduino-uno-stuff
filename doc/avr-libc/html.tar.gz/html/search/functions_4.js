var searchData=
[
  ['daylight_5fseconds',['daylight_seconds',['../group__avr__time.html#ga71762e360eaab527a334d9114f68aa21',1,'daylight_seconds(const time_t *timer):&#160;daylight_seconds.c'],['../group__avr__time.html#ga71762e360eaab527a334d9114f68aa21',1,'daylight_seconds(const time_t *timer):&#160;daylight_seconds.c']]],
  ['difftime',['difftime',['../group__avr__time.html#ga1732c46d47837951d399755899af5240',1,'difftime(time_t time1, time_t time0):&#160;difftime.c'],['../group__avr__time.html#ga1732c46d47837951d399755899af5240',1,'difftime(time_t t1, time_t t2):&#160;difftime.c']]],
  ['div',['div',['../group__avr__stdlib.html#ga7486ea9a8a90ac6b93bed37d08ebbd9e',1,'stdlib.h']]],
  ['dtostre',['dtostre',['../group__avr__stdlib.html#ga6c140bdd3b9bd740a1490137317caa44',1,'dtostre(double __val, char *__s, unsigned char __prec, unsigned char __flags):&#160;dtostre.c'],['../group__avr__stdlib.html#ga6c140bdd3b9bd740a1490137317caa44',1,'dtostre(double val, char *sbeg, unsigned char prec, unsigned char flags):&#160;dtostre.c']]],
  ['dtostrf',['dtostrf',['../group__avr__stdlib.html#ga060c998e77fb5fc0d3168b3ce8771d42',1,'dtostrf(double __val, signed char __width, unsigned char __prec, char *__s):&#160;dtostrf.c'],['../group__avr__stdlib.html#ga060c998e77fb5fc0d3168b3ce8771d42',1,'dtostrf(double val, signed char width, unsigned char prec, char *sout):&#160;dtostrf.c']]]
];
