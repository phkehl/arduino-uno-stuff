var searchData=
[
  ['gets',['gets',['../group__avr__stdio.html#gaf577dcba9afe50a9d068d0b69ac85d2f',1,'gets(char *__str):&#160;gets.c'],['../group__avr__stdio.html#gaf577dcba9afe50a9d068d0b69ac85d2f',1,'gets(char *str):&#160;gets.c']]],
  ['gm_5fsidereal',['gm_sidereal',['../group__avr__time.html#gaae725f7944578bf948bb5c44588b7b7c',1,'gm_sidereal(const time_t *timer):&#160;gm_sidereal.c'],['../group__avr__time.html#gaae725f7944578bf948bb5c44588b7b7c',1,'gm_sidereal(const time_t *timer):&#160;gm_sidereal.c']]],
  ['gmtime',['gmtime',['../group__avr__time.html#gae76343d6a51c93b9318ac0ced05225cd',1,'gmtime(const time_t *timer):&#160;gmtime.c'],['../group__avr__time.html#gae76343d6a51c93b9318ac0ced05225cd',1,'gmtime(const time_t *timeptr):&#160;gmtime.c']]],
  ['gmtime_5fr',['gmtime_r',['../group__avr__time.html#ga7cb461118a6aeebeaacd48ee127b952a',1,'gmtime_r(const time_t *timer, struct tm *timeptr):&#160;gmtime_r.c'],['../group__avr__time.html#ga7cb461118a6aeebeaacd48ee127b952a',1,'gmtime_r(const time_t *timer, struct tm *timeptr):&#160;gmtime_r.c']]]
];
