var searchData=
[
  ['labs',['labs',['../group__avr__stdlib.html#gae017047d6d0a688ccb622ff062dcd230',1,'labs(long __i):&#160;labs.c'],['../group__avr__stdlib.html#gae017047d6d0a688ccb622ff062dcd230',1,'labs(long x):&#160;labs.c']]],
  ['ldexp',['ldexp',['../group__avr__math.html#ga91643e944a94341bd2a3ed1d3ffbae4f',1,'math.h']]],
  ['ldiv',['ldiv',['../group__avr__stdlib.html#ga5b688b463f9faaa82f31ac7587e06849',1,'stdlib.h']]],
  ['lm_5fsidereal',['lm_sidereal',['../group__avr__time.html#ga9136313e476a6277cb6ca759542b83e3',1,'lm_sidereal(const time_t *timer):&#160;lm_sidereal.c'],['../group__avr__time.html#ga9136313e476a6277cb6ca759542b83e3',1,'lm_sidereal(const time_t *timer):&#160;lm_sidereal.c']]],
  ['localtime',['localtime',['../group__avr__time.html#gaa9336f97d394e8e02d97b9ff4fb0aca2',1,'localtime(const time_t *timer):&#160;localtime.c'],['../group__avr__time.html#gaa9336f97d394e8e02d97b9ff4fb0aca2',1,'localtime(const time_t *timer):&#160;localtime.c']]],
  ['localtime_5fr',['localtime_r',['../group__avr__time.html#gacd9715002deaf28b432a8f2b54dd9aa5',1,'localtime_r(const time_t *timer, struct tm *timeptr):&#160;localtime_r.c'],['../group__avr__time.html#gacd9715002deaf28b432a8f2b54dd9aa5',1,'localtime_r(const time_t *timer, struct tm *timeptr):&#160;localtime_r.c']]],
  ['log',['log',['../group__avr__math.html#ga7f7d556ab6b6235777a179647c152126',1,'math.h']]],
  ['log10',['log10',['../group__avr__math.html#ga3630cb8cef4560cf0d92e82ae05b03f0',1,'math.h']]],
  ['longjmp',['longjmp',['../group__setjmp.html#ga87f44eafaab5ec0ef8f5a11a8b853acf',1,'setjmp.h']]],
  ['lrint',['lrint',['../group__avr__math.html#ga9b995838b7bdd4886549dd7e308d0619',1,'math.h']]],
  ['lround',['lround',['../group__avr__math.html#gaa759c9a1684b0cf2c4c5d133771192ce',1,'math.h']]],
  ['ltoa',['ltoa',['../group__avr__stdlib.html#ga5a3fce5fbd20140584619ba9aed09f75',1,'stdlib.h']]]
];
