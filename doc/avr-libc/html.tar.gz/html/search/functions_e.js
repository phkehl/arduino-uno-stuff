var searchData=
[
  ['rand',['rand',['../group__avr__stdlib.html#gae23144bcbb8e3742b00eb687c36654d1',1,'rand(void):&#160;rand.c'],['../group__avr__stdlib.html#gae23144bcbb8e3742b00eb687c36654d1',1,'rand(void):&#160;rand.c']]],
  ['rand_5fr',['rand_r',['../group__avr__stdlib.html#gaf5085001be836a0f2a5d3269a7c9fd04',1,'rand_r(unsigned long *__ctx):&#160;rand.c'],['../group__avr__stdlib.html#gaf5085001be836a0f2a5d3269a7c9fd04',1,'rand_r(unsigned long *ctx):&#160;rand.c']]],
  ['random',['random',['../group__avr__stdlib.html#ga114aeb1751119382aaf3340355b22cfd',1,'random(void):&#160;random.c'],['../group__avr__stdlib.html#ga114aeb1751119382aaf3340355b22cfd',1,'random(void):&#160;random.c']]],
  ['random_5fr',['random_r',['../group__avr__stdlib.html#gaa99a0733f06d2b9960a1401c2721af1e',1,'random_r(unsigned long *__ctx):&#160;random.c'],['../group__avr__stdlib.html#gaa99a0733f06d2b9960a1401c2721af1e',1,'random_r(unsigned long *ctx):&#160;random.c']]],
  ['realloc',['realloc',['../group__avr__stdlib.html#gafd300bad8b4dd2e88b07d464d76c92aa',1,'realloc(void *__ptr, size_t __size) __ATTR_MALLOC__:&#160;realloc.c'],['../group__avr__stdlib.html#gafd300bad8b4dd2e88b07d464d76c92aa',1,'realloc(void *ptr, size_t len):&#160;realloc.c']]],
  ['round',['round',['../group__avr__math.html#ga6eb04604d801054c5a2afe195d1dd75d',1,'math.h']]]
];
