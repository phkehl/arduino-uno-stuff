var searchData=
[
  ['additional_20notes_20from_20_3cavr_2fsfr_5fdefs_2eh_3e',['Additional notes from &lt;avr/sfr_defs.h&gt;',['../group__avr__sfr__notes.html',1,'']]],
  ['a_20simple_20project',['A simple project',['../group__demo__project.html',1,'']]],
  ['a_20more_20sophisticated_20project',['A more sophisticated project',['../group__largedemo.html',1,'']]]
];
