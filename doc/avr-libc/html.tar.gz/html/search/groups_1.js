var searchData=
[
  ['combining_20c_20and_20assembly_20source_20files',['Combining C and assembly source files',['../group__asmdemo.html',1,'']]]
];
