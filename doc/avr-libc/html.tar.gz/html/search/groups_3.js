var searchData=
[
  ['example_20using_20the_20two_2dwire_20interface_20_28twi_29',['Example using the two-wire interface (TWI)',['../group__twi__demo.html',1,'']]]
];
