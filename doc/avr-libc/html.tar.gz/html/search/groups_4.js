var searchData=
[
  ['using_20the_20standard_20io_20facilities',['Using the standard IO facilities',['../group__stdiodemo.html',1,'']]]
];
