var searchData=
[
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['data_20in_20program_20space',['Data in Program Space',['../pgmspace.html',1,'']]]
];
