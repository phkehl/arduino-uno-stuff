var searchData=
[
  ['memory_20areas_20and_20using_20malloc_28_29',['Memory Areas and Using malloc()',['../malloc.html',1,'']]],
  ['memory_20sections',['Memory Sections',['../mem_sections.html',1,'']]]
];
