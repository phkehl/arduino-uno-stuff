var searchData=
[
  ['release_20numbering_20and_20methodology',['Release Numbering and Methodology',['../release_method.html',1,'']]]
];
