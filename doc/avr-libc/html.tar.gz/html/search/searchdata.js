var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvwy",
  1: "dltw",
  2: "abcdefilmpstuw",
  3: "_abcdefghilmpqrstuvw",
  4: "_deqrtwy",
  5: "_fiptu",
  6: "_",
  7: "c",
  8: "acdeu",
  9: "abcdfhimprtu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

