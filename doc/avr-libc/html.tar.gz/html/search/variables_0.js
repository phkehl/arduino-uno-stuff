var searchData=
[
  ['_5f_5fmalloc_5fheap_5fend',['__malloc_heap_end',['../group__avr__stdlib.html#ga4d7b1bf0f75d529cc75229a266132115',1,'__malloc_heap_end():&#160;malloc.c'],['../group__avr__stdlib.html#ga4d7b1bf0f75d529cc75229a266132115',1,'__malloc_heap_end():&#160;malloc.c'],['../group__avr__stdlib.html#ga4d7b1bf0f75d529cc75229a266132115',1,'__malloc_heap_end():&#160;malloc.c']]],
  ['_5f_5fmalloc_5fheap_5fstart',['__malloc_heap_start',['../group__avr__stdlib.html#ga9310042b3956282440c091d20cb98c5f',1,'__malloc_heap_start():&#160;malloc.c'],['../group__avr__stdlib.html#ga9310042b3956282440c091d20cb98c5f',1,'__malloc_heap_start():&#160;malloc.c'],['../group__avr__stdlib.html#ga9310042b3956282440c091d20cb98c5f',1,'__malloc_heap_start():&#160;malloc.c']]],
  ['_5f_5fmalloc_5fmargin',['__malloc_margin',['../group__avr__stdlib.html#gaffadd67736fd340e893fb22c207de597',1,'__malloc_margin():&#160;malloc.c'],['../group__avr__stdlib.html#gaffadd67736fd340e893fb22c207de597',1,'__malloc_margin():&#160;malloc.c'],['../group__avr__stdlib.html#gaffadd67736fd340e893fb22c207de597',1,'__malloc_margin():&#160;malloc.c']]]
];
