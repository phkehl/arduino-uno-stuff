var searchData=
[
  ['errno',['errno',['../group__avr__errno.html#gad65a8842cc674e3ddf69355898c0ecbf',1,'errno():&#160;errno.c'],['../group__avr__errno.html#gad65a8842cc674e3ddf69355898c0ecbf',1,'errno():&#160;errno.c']]]
];
