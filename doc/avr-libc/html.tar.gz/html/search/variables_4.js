var searchData=
[
  ['rem',['rem',['../structdiv__t.html#ac64389de252de53eda8b4f8dbb7c623f',1,'div_t::rem()'],['../structldiv__t.html#a0f217ff62b8640aa945ec84d6d0bd000',1,'ldiv_t::rem()']]]
];
