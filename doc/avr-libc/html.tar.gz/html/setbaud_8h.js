var setbaud_8h =
[
    [ "BAUD_TOL", "group__util__setbaud.html#gaddaa61b72aca51ed4835978d500f8755", null ],
    [ "UBRR_VALUE", "group__util__setbaud.html#ga0b029ff580b042a27aaac4bd2ec925e2", null ],
    [ "UBRRH_VALUE", "group__util__setbaud.html#ga8188daef772f5eb3fc81dfee168905e2", null ],
    [ "UBRRL_VALUE", "group__util__setbaud.html#ga39ebec5d04e582b7b6ed9a72b973983c", null ],
    [ "USE_2X", "group__util__setbaud.html#ga6977ce48ae3197f3f016b85d98380509", null ]
];