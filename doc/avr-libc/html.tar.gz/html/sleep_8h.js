var sleep_8h =
[
    [ "_SLEEP_CONTROL_REG", "sleep_8h.html#a1a0221ee000bb91407ab3f410f830b08", null ],
    [ "_SLEEP_ENABLE_MASK", "sleep_8h.html#a6cf481cda733c2b30bdcfe92a59c0493", null ],
    [ "sleep_bod_disable", "sleep_8h.html#abf889562cc5ea768ee80cfc8a5bb0312", null ],
    [ "sleep_cpu", "group__avr__sleep.html#ga157b2578d95309c197b739f812938d94", null ],
    [ "sleep_disable", "group__avr__sleep.html#gaeae22433a78fd8d50f915fb68c416efd", null ],
    [ "sleep_enable", "group__avr__sleep.html#ga475174a7aa4eda03dfa7a4483e400a9e", null ],
    [ "sleep_mode", "sleep_8h.html#a3775b21f297187752bcfc434a541209a", null ]
];