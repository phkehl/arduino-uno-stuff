var structatexit__s =
[
    [ "fun", "structatexit__s.html#adc22ee6e4a01745580da98845b1e32aa", null ],
    [ "next", "structatexit__s.html#accd829210fa827fcee51e44222524698", null ]
];