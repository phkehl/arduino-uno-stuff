var structdiv__t =
[
    [ "quot", "structdiv__t.html#a0b9dda2884048daa68ca4aaa12b17b9a", null ],
    [ "rem", "structdiv__t.html#ac64389de252de53eda8b4f8dbb7c623f", null ]
];