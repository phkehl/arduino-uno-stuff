var structldiv__t =
[
    [ "quot", "structldiv__t.html#a73efd59c176304c327cb4214d0e5e5c9", null ],
    [ "rem", "structldiv__t.html#a0f217ff62b8640aa945ec84d6d0bd000", null ]
];