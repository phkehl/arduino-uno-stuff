var wdt_8h =
[
    [ "_WD_CHANGE_BIT", "wdt_8h.html#aa8e489cdf7dd38145a8c4bcdce02fa26", null ],
    [ "_WD_CONTROL_REG", "wdt_8h.html#a76eed466e046b7a7dbc759f888eb3d71", null ],
    [ "_WD_PS3_MASK", "wdt_8h.html#a31e957041a2a6f2b1ad219eb4688a0ee", null ],
    [ "wdt_disable", "group__avr__watchdog.html#gab3784e1b871d61ed338da5658184b725", null ],
    [ "wdt_enable", "group__avr__watchdog.html#gaf6cfea2a1b61e2530ea0c4ef8fc572b3", null ],
    [ "wdt_reset", "group__avr__watchdog.html#ga9e52c54d10b6a6a7ce04aaaa4abea51f", null ],
    [ "WDTO_120MS", "group__avr__watchdog.html#ga7d028bcdb4a4103549fc6fb4ec07fbcd", null ],
    [ "WDTO_15MS", "group__avr__watchdog.html#gad45893280f49113ffc2e67e1d741f29d", null ],
    [ "WDTO_1S", "group__avr__watchdog.html#ga36302e15f38a4eeb8a328724bb8165e9", null ],
    [ "WDTO_250MS", "group__avr__watchdog.html#ga66d5f50cc76b92c76900d77ef577d53e", null ],
    [ "WDTO_2S", "group__avr__watchdog.html#ga05fc682d276a36d8cc4e9178340ff004", null ],
    [ "WDTO_30MS", "group__avr__watchdog.html#ga057dd21dc54e71de0e20d8bd5734915d", null ],
    [ "WDTO_4S", "group__avr__watchdog.html#ga752b0b1b5ba9009bc09976494313e30d", null ],
    [ "WDTO_500MS", "group__avr__watchdog.html#gacf89fc5fb6c8aa9efaadb86872cfbcdf", null ],
    [ "WDTO_60MS", "group__avr__watchdog.html#ga7a5b072c51c05a34cc38111f0e6724e5", null ],
    [ "WDTO_8S", "group__avr__watchdog.html#gaf074e538b2a1d5031931530f29a09fce", null ]
];