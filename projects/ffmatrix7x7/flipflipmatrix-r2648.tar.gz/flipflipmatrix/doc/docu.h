// $Id: docu.h 2642 2013-09-21 14:01:36Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/doc/docu.h $

#ifndef __DOCU_H_
#define __DOCU_H__ //!< multiple inclusion guard

/*!

\file
\brief flipflipMATRIX documentation

- Copyright (c) 2012 Philippe Kehl < flipflip at gmx dot net >

\mainpage

This is the documentation...

\section P_MAIN_CONTENTS Contents

- \ref P_INTRO
- \ref P_HARDWARE
- \ref P_SOFTWARE
- \ref P_NOTES
- \ref P_REFERENCES
- \ref <a class="el" href="todo.html">Todo List</a>
- \ref P_DOXYGEN
- Sources? here: main()


\section P_MAIN_COPYRIGHT Copyright

All contents (documentation, source code, ...) copyright (c) 2012 Philippe
Kehl &lt;phkehl at gmail dot com&gt; (unless other sources are referenced). All
rights reserved. All trademarks property of their respective owners.

External libraries

- \ref ATOM Open Source RTOS, http://atomthreads.com/, Copyright (c) 2010,
  Kelvin Lawson, see source code (src/atomkernel.c, src/atommutex.c,
  src/atomport-asm.s, src/atomport.c, src/atomport.h, src/atomqueue.c,
  src/atomsem.c, src/atomthreads.h, and src/atomtimer.c) for details

\section P_MAIN_CREDITS Credits

- the Internet, AVR freaks forum, et al.



\page P_INTRO Intro

Yeah, right, ...

\todo write intro.. :)

*/

/* ************************************************************************** */

/*!

\page P_HARDWARE Hardware

\section P_HARDWARE_PINS MCU Pins

\image html atmega168.png The AVR ATmega 168 pins [AVR8271]

\section P_HARDWARE_RES MCU Ressources

- \ref TASKS & \ref ATOM
  - timer/counter0 to generate a 1ms scheduler tick
  - PD4 lit when a task is running (otherwise in idle task)
  - PD3 toggled in system ticks interrupt

- \ref MATRIX
  - PC5 lit while flushing out data to the LEDs

- \ref DEBUG
  - PD1 data tx pin

\section P_HARDWARE_FUSES MCU Fuses

The fuse settings are (0 = programmed, 1 = unprogrammed):

- lfuse = 0xd7 = 01101 0111 (CKSEL = 0010, SUT = 10, CKDIV8 = 0)
  - bit7: 0 CKDIV8   -- divide clock by 8           -> clock is not divided by 8
  - bit6: 1 CKOUT    -- clock output enable         -> clock output is not enabled
  - bit5: 1 SUT1     -- select start-up time
  - bit4: 0 SUT0     -- select start-up time
  - bit3: 0 CKSEL3   -- select clock source
  - bit2: 0 CKSEL2   -- select clock source
  - bit1: 1 CKSEL1   -- select clock source
  - bit0: 0 CKSEL0   -- select clock source
- hfuse = 0xd9 = 1101 1001
  - bit7: 1 RSTDISBL -- external reset disable      -> external reset is not disabled
  - bit6: 1 DWEN     -- debug wire enable           -> debug wire is not enabled
  - bit5: 0 SPIEN    -- SPI programming             -> SPI programming is enabled
  - bit4: 1 WDTON    -- watchdog timer always on    -> wd timer is not always on
  - bit3: 1 EESAVE   -- EEPROM memory preserved.    -> not enabled
  - bit2: 0 BOOTSZ1  -- boot size select
  - bit1: 0 BOOTSZ0  -- boot size select
  - bit0: 1 BOOTRST  -- select reset vector
- efuse = 0xff = 0000 0111
  - bit7: 0 -
  - bit6: 0 -
  - bit5: 0 -
  - bit4: 0 -
  - bit3: 0 -
  - bit2: 1 BODLEVEL2 -- Brown-out Detector trigger level
  - bit1: 1 BODLEVEL1 -- Brown-out Detector trigger level
  - bit0: 1 BODLEVEL0 -- Brown-out Detector trigger level

\section P_HARDWARE_FTDI Serial Debug (FTDI Cable)

  - green: RTS#
  - yellow: RXD
  - orange: TXD
  - red: VCC
  - brown: CTS#
  - black: GND

\section P_HARDWARE_SCHEMATICS Schematics

\image html schematics.png


*/

/* ************************************************************************** */

/*!

\page P_SOFTWARE Software

\section P_SOFTWARE_CONCEPTS Concepts

What?!

\section P_SOFTWARE_RGBHSV RGB -- HSV

\image html HSV-RGB-comparison_svg_wikipedia.png HSV-RGB-comparison [http://en.wikipedia.org/wiki/File:HSV-RGB-comparison.svg]



*/

/* ************************************************************************** */

/*!

\page P_NOTES Notes

\section P_NOTES_STUFF Stuff

- avr-libc headers are in /usr/lib/avr/include (and /usr/lib/avr/include/avr)
- http://www.ladyada.net/library/arduino/index.html

\section P_NOTES_USBTINY USBtinyISP

- http://learn.adafruit.com/usbtinyisp/overview
- /etc/udev/rules.d/99-usbtiny.rules:
  SUBSYSTEM=="usb", ATTR{product}=="USBtiny", ATTR{idProduct}=="0c9f", ATTRS{idVendor}=="1781", MODE="0666"



\section P_NOTES_RELATED Related

- ...

\section P_NOTES_AVRLIBCDOC Generate a readable avr-libc documentation

\verbatim
wget http://download.savannah.gnu.org/releases/avr-libc/avr-libc-1.6.8.tar.bz2
tar -xjvf avr-libc-1.6.8.tar.bz2
patch -p0 < avr-libc-1.6.8-docu.patch
./configure --prefix=/tmp/foo --build=`./config.guess` --host=avr --enable-doc --enable-html-doc --enable-man-doc
make -C doc
\endverbatim


\section P_NOTES_ARDUINOISP Arduino as Programmer

- http://arduino.cc/en/Tutorial/ArduinoISP
- http://arduino.cc/en/Tutorial/ArduinoToBreadboard
- http://teholabs.com/knowledge/kicad.html

*/

/* ************************************************************************** */

/*!

\page P_REFERENCES References

- [AVR8271] 8-bit Microcontroller with 4/8/16/32K Bytes In-System Programmable
  Flash ATmega48A / ATmega48PA / ATmega88A / ATmega88PA / ATmega168A /
  ATmega168PA / ATmega328 / ATmega328P -- Datasheet / Manual,
  Rev. 8271C–AVR–08/10
  (Datasheet:AVR_doc8271S_atmega_48_88_168_328.pdf)

- [AVR2513] 8-bit Microcontroller with 16K Bytes In-System Programmable Flash
  ATmega162 / ATmega162V -- Datasheet / Manual
  (Datasheet:AVR_doc2513_atmega_162.pdf)

- [AVR2505] AVR130: Setup and Use the AVR Timers (Application note 130)
  (Datasheet:AVR_doc2505_timers.pdf)

- [avr-libc] avr-libc (documentation), http://www.nongnu.org/avr-libc

- [avrdude] AVRDUDE programmer, http://www.nongnu.org/avrdude/

- [ATMEGA328P] http://www.atmel.com/devices/atmega328p.aspx?tab=documents

- [HD44780] http://www.mikrocontroller.net/articles/HD44780

*/

/* ************************************************************************** */

/*!

\page P_DOXYGEN Doxygen Report

\verbatim
%DOXYGEN_REPORT%
\endverbatim


*/

#endif // __DOCU_H__
// eof
