/**
    \file

    \brief Atom Threads Library (see \ref ATOM)

    \defgroup ATOM Atom Threads

    The library consists of the following modules:
    - \ref ATOM_KERNEL
    - \ref ATOM_QUEUE
    - \ref ATOM_TIMER
    - \ref ATOM_MUTEX
    - \ref ATOM_SEM
    - \ref ATOM_PORT

    @{

*/

#ifndef __ATOMTHREADS_H__
#define __ATOMTHREADS_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "atomport.h"

//! number of system ticks per second
#if !defined(SYSTICKS_HZ) || defined(_DOXYGEN_)
//#  define SYSTICKS_HZ 100
#  define SYSTICKS_HZ 1000
#endif

//! conversion macro [ms] -> [ticks]
#define MS2TICKS(ms) ( (ms) / (1000 / SYSTICKS_HZ) )


/* ***** types *************************************************************** */

/* Callback function prototype */
typedef void ( * TIMER_CB_FUNC ) ( POINTER cb_data ) ;

/* Timer descriptor */
typedef struct atom_timer
{
    TIMER_CB_FUNC   cb_func;    /* Callback function */
    POINTER	        cb_data;    /* Pointer to callback parameter/data */
    uint32_t	    cb_ticks;   /* Ticks until callback */

	/* Internal data */
    struct atom_timer *next_timer;		/* Next timer in doubly-linked list */

} ATOM_TIMER;


/* Forward declaration */
struct atom_tcb;

typedef struct atom_tcb
{
    /* Thread's current stack pointer. When a thread is scheduled
     * out the architecture port can save*/
    POINTER sp_save_ptr;

    /* Thread priority (0-255) */
    uint8_t priority;

    /* Thread entry point and parameter */
    void (*entry_point)(uint32_t);
    uint32_t entry_param;

    /* Queue pointers */
    struct atom_tcb *prev_tcb;    /* Previous TCB in doubly-linked TCB list */
    struct atom_tcb *next_tcb;    /* Next TCB in doubly-linked list */

    /* Suspension data */
    uint8_t suspended;            /* TRUE if task is currently suspended */
    uint8_t suspend_wake_status;  /* Status returned to woken suspend calls */
    ATOM_TIMER *suspend_timo_cb;  /* Callback registered for suspension timeouts */

    /* Details used if thread stack-checking is required */
#ifdef ATOM_STACK_CHECKING
    POINTER stack_bottom;         /* Pointer to bottom of stack allocation */
    uint32_t stack_size;          /* Size of stack allocation in bytes */
#endif

} ATOM_TCB;


typedef struct atom_queue
{
    ATOM_TCB *  putSuspQ;       /* Queue of threads waiting to send */
    ATOM_TCB *  getSuspQ;       /* Queue of threads waiting to receive */
    uint8_t *   buff_ptr;       /* Pointer to queue data area */
    uint32_t    unit_size;      /* Size of each message */
    uint32_t    max_num_msgs;   /* Max number of storable messages */
    uint32_t    insert_index;   /* Next byte index to insert into */
    uint32_t    remove_index;   /* Next byte index to remove from */
    uint32_t    num_msgs_stored;/* Number of messages stored */
} ATOM_QUEUE;

typedef struct atom_sem
{
    ATOM_TCB *  suspQ;  /* Queue of threads suspended on this semaphore */
    uint8_t       count;  /* Semaphore count */
} ATOM_SEM;


typedef struct atom_mutex
{
    ATOM_TCB *  suspQ;  /* Queue of threads suspended on this mutex */
    ATOM_TCB *  owner;  /* Thread which currently owns the lock */
    uint8_t     count;  /* Recursive count of locks by the owner  */
} ATOM_MUTEX;



/* Constants */
//#ifndef TRUE
#  define TRUE                    1
//#endif
//#ifndef FALSE
#  define FALSE                   0
//#endif


/* Error values */

#define ATOM_OK                 0
#define ATOM_ERROR              1
#define ATOM_TIMEOUT            2
#define ATOM_WOULDBLOCK         3
#define ATOM_ERR_CONTEXT        200
#define ATOM_ERR_PARAM          201
#define ATOM_ERR_DELETED        202
#define ATOM_ERR_OVF            203
#define ATOM_ERR_QUEUE          204
#define ATOM_ERR_TIMER          205
#define ATOM_ERR_NOT_FOUND      206
#define ATOM_ERR_OWNERSHIP      207

/* Idle thread priority (lowest) */
#define IDLE_THREAD_PRIORITY    255




/* ***** atomkernel.c ******************************************************** */

uint8_t atomOSInit (void *idle_thread_stack_bottom, uint32_t idle_thread_stack_size, uint8_t idle_thread_stack_check);
void atomOSStart (void);

void atomSched (uint8_t timer_tick);

void atomIntEnter (void);
void atomIntExit (uint8_t timer_tick);


ATOM_TCB *atomCurrentContext (void);

uint8_t atomThreadCreate (ATOM_TCB *tcb_ptr, uint8_t priority, void (*entry_point)(uint32_t), uint32_t entry_param, void *stack_bottom, uint32_t stack_size, uint8_t stack_check);
uint8_t atomThreadStackCheck (ATOM_TCB *tcb_ptr, uint32_t *used_bytes, uint32_t *free_bytes);


uint8_t tcbEnqueuePriority (ATOM_TCB **tcb_queue_ptr, ATOM_TCB *tcb_ptr);
ATOM_TCB *tcbDequeueHead (ATOM_TCB **tcb_queue_ptr);
ATOM_TCB *tcbDequeueEntry (ATOM_TCB **tcb_queue_ptr, ATOM_TCB *tcb_ptr);
ATOM_TCB *tcbDequeuePriority (ATOM_TCB **tcb_queue_ptr, uint8_t priority);


// in atomport-asm.s
extern void archContextSwitch (ATOM_TCB *old_tcb_ptr, ATOM_TCB *new_tcb_ptr);
extern void archFirstThreadRestore(ATOM_TCB *new_tcb_ptr);
// in atomport.c
extern void archThreadContextInit (ATOM_TCB *tcb_ptr, void *stack_top, void (*entry_point)(uint32_t), uint32_t entry_param);


ATOM_TCB *atomGetIdleTCB(void);



/* ***** atomtimer.c ******************************************************** */

uint8_t atomTimerRegister (ATOM_TIMER *timer_ptr);
uint8_t atomTimerCancel (ATOM_TIMER *timer_ptr);
uint8_t atomTimerDelay (uint32_t ticks);
uint32_t atomTimeGet (void);
void atomTimeSet (uint32_t new_time);

void atomTimerTick (void);




/* ***** atomqueu.c ******************************************************** */

uint8_t atomQueueCreate (ATOM_QUEUE *qptr, uint8_t *buff_ptr, uint32_t unit_size, uint32_t max_num_msgs);
uint8_t atomQueueDelete (ATOM_QUEUE *qptr);
uint8_t atomQueueGet (ATOM_QUEUE *qptr, int32_t timeout, uint8_t *msgptr);
uint8_t atomQueuePut (ATOM_QUEUE *qptr, int32_t timeout, uint8_t *msgptr);





/* ***** atomsem.c ******************************************************** */

uint8_t atomSemCreate (ATOM_SEM *sem, uint8_t initial_count);
uint8_t atomSemDelete (ATOM_SEM *sem);
uint8_t atomSemGet (ATOM_SEM *sem, int32_t timeout);
uint8_t atomSemPut (ATOM_SEM *sem);
uint8_t atomSemResetCount (ATOM_SEM *sem, uint8_t count);




/* ***** atommutex.c ******************************************************** */

uint8_t atomMutexCreate (ATOM_MUTEX *mutex);
uint8_t atomMutexDelete (ATOM_MUTEX *mutex);
uint8_t atomMutexGet (ATOM_MUTEX *mutex, int32_t timeout);
uint8_t atomMutexPut (ATOM_MUTEX *mutex);






#ifdef __cplusplus
}
#endif

#endif /* __ATOMTHREADS_H__ */

//@}
