// $Id: debug.c 2644 2013-09-22 20:59:22Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/debug.c $
/*!
    \file
    \brief flipflipMATRIX debugging implementation (see \ref DEBUG)

    - Copyright (c) 2011-2013 Philippe Kehl < phkehl at gmail dot com >

    \addtogroup DEBUG
    @{
*/


#include <stdio.h>
#include <string.h>

#include "stdstuff.h"
#include "debug.h"

#include "atomthreads.h"


#if !defined(__AVR_ATmega328P__) && !defined(__AVR_ATmega168__)
#  error Missing configuration for your target device!
#endif

#if (F_CPU == 16000000) || defined(_DOXYGEN_)
#  define DEBUG_BRDELAY (16)   //!< delay to achieve correct baudrate (this gives me 115200, YMMV)
#else
#  error Missing configuration for your F_CPU setting.
#endif


//! adds a character to the tx buffer
/*!
    Adds a character to the tx buffer, possibly waiting until there is space.

    \note This is used by the stdio subsystem, (printf() et al.).

    \param c      the character to put into the buffer
    \param pFile  the file handle (not actually used)

    \returns 1 on error (no more space in output buffer),
             0 if okay (character queued for output)
*/
static I sDebugPutChar(IN CH c, IN FILE *pFile);

//! the debug file handle (write-only)
static FILE sDebugDev = FDEV_SETUP_STREAM(sDebugPutChar, NULL, _FDEV_SETUP_WRITE);


#define DEBUG_BUFSIZE 256           //!< buffer size for debugging output

static CH sDebugBuf[DEBUG_BUFSIZE]; //!< debug tx buffer
static U1 sDebugBufHead;            //!< write-to-buffer pointer (index)
static U1 sDebugBufTail;            //!< read-from-buffer pointer (index)
static U1 sDebugBufSize;            //!< size of buffered data


#define INI_TXOUT  SETBITS(DDRD, BIT(PD1))     //!< initialise serial tx pin
#define ENA_TXOUT  SETBITS(PORTD, BIT(PD1))    //!< set tx pin high
#define DIS_TXOUT  CLEARBITS(PORTD, BIT(PD1))  //!< set tx pin low

#define INI_RXIN   SETBITS(DDRD, BIT(PD0)); SETBITS(PORTD, BIT(PD0)) //!< initialise serial rx pin

#define INI_TXDBG  /*SETBITS(DDRC, BIT(PC4))*/     //!< initialise serial tx debugging pin
#define ENA_TXDBG  /*SETBITS(PORTC, BIT(PC4));*/   //!< set tx debug pin high
#define DIS_TXDBG  /*CLEARBITS(PORTC, BIT(PC4));*/ //!< set tx debug pin low


void debugInit(void)
{
    // setup tx pin
    INI_TXOUT;
    ENA_TXOUT;

    // setup rx pin
    INI_RXIN;

    // setup tx debugging pin
    INI_TXDBG;
    DIS_TXDBG;

    // assign the debug port to stdout
    stdout = &sDebugDev;

    // initialise the output buffer
    sDebugBufHead = 0;
    sDebugBufTail = 0;
    sDebugBufSize = 0;

    // clear screen (at least in some terminals) and say hello
    printf_P(PSTR("\033[2J"));
    DEBUG("debug: init"); FLUSH;
}


static I sDebugPutChar(IN CH c, IN FILE *pFile)
{
    I res = 1;
    UNUSED(pFile);

    CS_ENTER;
    if ( (sDebugBufSize == 0) || (sDebugBufHead != sDebugBufTail) )
    {
        sDebugBuf[sDebugBufHead] = c;
        sDebugBufHead += 1;
        sDebugBufHead %= DEBUG_BUFSIZE;
        sDebugBufSize++;
        res = 0;
    }
    CS_LEAVE;

    return res;
}


//! do the proper delay to achieve our baudrate
/*!
    Delays the software serial tx to achieve the correct baudrate. Stolen from
    Arduino's SoftwareSerial.cpp (GPL).

    \param delay  delay parameter
*/
static inline void sDebugTunedDelay(uint16_t delay)
{
    uint8_t tmp = 0;

    __asm__ __volatile__ /* was: asm volatile */
   (
       "sbiw    %0, 0x01 \n\t"
       "ldi %1, 0xFF \n\t"
       "cpi %A0, 0xFF \n\t"
       "cpc %B0, %1 \n\t"
       "brne .-10 \n\t"
       : "+r" (delay), "+a" (tmp)
       : "0" (delay)
   );
}


U1 debugFlush(void)
{
    CS_ENTER; // interrupts off

    // send queued characters
    if (sDebugBufSize)
    {
        // enable tx debugging LED
        ENA_TXDBG;

        // character to send
        const CH c = /*~*/sDebugBuf[sDebugBufTail];

        // start bit
        DIS_TXOUT;
        sDebugTunedDelay(DEBUG_BRDELAY + 5);

        // write all 8 bits
        for (U1 mask = 0x01; mask; mask <<= 1)
        {
            if (c & mask) // choose bit
            {
                ENA_TXOUT;
            }
            else
            {
                DIS_TXOUT;
            }
            sDebugTunedDelay(DEBUG_BRDELAY);
        }

        // stop bit
        ENA_TXOUT;
        sDebugTunedDelay(DEBUG_BRDELAY);

        // move tail
        sDebugBufTail += 1;
        sDebugBufTail %= DEBUG_BUFSIZE;
        sDebugBufSize--;

        // turn tx debugging LED off
        DIS_TXDBG;
    }

    CS_LEAVE; // possibly interupts on again

    return sDebugBufSize;
}

void debugTask(U4 data)
{
    UNUSED(data);

    while (ENDLESS)
    {
        while (debugFlush());
        atomTimerDelay(MS2TICKS(10));
    }
}


void debugConsts(IN const DEBUG_CONSTS_t k)
{
    switch (k)
    {
        case DEBUG_NOTICE:
            printf_P(PSTR("N: "));
            break;

        case DEBUG_WARNING:
            printf_P(PSTR("W: "));
            break;

        case DEBUG_ERROR:
            printf_P(PSTR("E: "));
            break;

        case DEBUG_DEBUG:
#if (DEBUGLEVEL > 0)
            printf_P(PSTR("D: "));
#endif
            break;

        case DEBUG_CRLF:
            printf_P(PSTR("\r\n"));
            break;
    }
}


//@}
// eof
