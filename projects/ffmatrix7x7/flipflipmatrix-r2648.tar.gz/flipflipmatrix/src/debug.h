// $Id: debug.h 2502 2012-11-04 22:49:35Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/debug.h $
/*!
    \file
    \brief flipflipMATRIX debugging headers (see \ref DEBUG)

    - Copyright (c) 2012 Philippe Kehl < phkehl at gmail dot com >

    \defgroup DEBUG Debugging Routines
    @{

    This implements debugging data output via a nasty software serial port tx
    on a pin. It assigns stdout to this so that the standard printf() et al.
    route to this. Output data goes into a ring buffer that is flushed to the
    serial port using debugFlush(). A suitable \ref THREADS task is used to
    keep it rolling. This should provide enough bandwidth to print a lot of
    stuff.

    \todo use a timer to generate the baudrate instead of the nasty software
          delay routine

    \todo use hw serial port
*/

#ifndef __DEBUG_H__
#define __DEBUG_H__ //!< multiple inclusion guard

#include <stdio.h>
#include <avr/pgmspace.h>

#include "stdstuff.h"


#if !defined(DEBUGLEVEL) || defined(_DOXYGEN_)
#  define DEBUGLEVEL 0 //!< debugging code (messages, mainly) enabled
#endif


//! initialises the debugging subsystem
/*!
    Initialises the debugging subsystem (set port, baud rate, enable stdio
    stream).

    \note This must be called before using any of the debugging macros and
          functions below.
*/
void debugInit(void);

//! flush debug buffer to serial port
/*!
    Flushes one char of the debug buffer to the serial port.
    See also FLUSH().

    \return number of bytes left in output queue
*/
U1 debugFlush(void);


//! the debug flush task
/*!
    Task that constantly flushes pending debug output data.

    \param data  task parameters (unused)
*/
void debugTask(U4 data);


//! frequently used string constants enumerator
typedef enum DEBUG_CONSTS_e
{
    DEBUG_NOTICE,   //!< "N: "
    DEBUG_WARNING,  //!< "W: "
    DEBUG_ERROR,    //!< "E: "
    DEBUG_DEBUG,    //!< "D: "
    DEBUG_CRLF,     //!< "\r\n"
} DEBUG_CONSTS_t;


//! prints some frequently used string constants
/*!
    Prints the selected string constant.

    \param k  the string constant enumerator
*/
void debugConsts(IN const DEBUG_CONSTS_t k);


//! prints a notice to the debug port
/*!
    Prints the formatted notice message to the debug port, automatically
    prepended with "N: ".

    \param fmt   the format (PROGMEM string!)
    \param args  zero or more arguments
*/
#define NOTICE(fmt, args...) \
    debugConsts(DEBUG_NOTICE); printf_P(PSTR(fmt), ## args); debugConsts(DEBUG_CRLF)


//! prints a warning to the debug port
/*!
    Prints the formatted warning message to the debug port, automatically
    prepended with "W: ".

    \param fmt   the format (PROGMEM string!)
    \param args  zero or more arguments
*/
#define WARNING(fmt, args...) \
    debugConsts(DEBUG_WARNING); printf_P(PSTR(fmt), ## args); debugConsts(DEBUG_CRLF)


//! prints an error to the debug port
/*!
    Prints the formatted error message to the debug port, automatically
    prepended with "E: ".

    \param fmt   the format (PROGMEM string!)
    \param args  zero or more arguments
*/
#define ERROR(fmt, args...) \
    debugConsts(DEBUG_ERROR); printf_P(PSTR(fmt), ## args); debugConsts(DEBUG_CRLF)


//! prints a debug message to the debug port
/*!
    Prints the formatted debug message to the debug port (if #DEBUG >= 1),
    automatically prepended with "D: ".

    \param fmt   the format (PROGMEM string!)
    \param args  zero or more arguments
*/
#if ( (DEBUGLEVEL > 0) || defined(_DOXYGEN_) )
#  define DEBUG(fmt, args...) \
    debugConsts(DEBUG_DEBUG); printf_P(PSTR(fmt), ## args); debugConsts(DEBUG_CRLF)
#else
#  define DEBUG(...) /* nothing */
#endif


//! flush debug output buffer immediately, blocking all tasks
#define FLUSH   CS_ENTER; while (debugFlush()); CS_LEAVE

#endif // __DEBUG_H__

//@}
// eof
