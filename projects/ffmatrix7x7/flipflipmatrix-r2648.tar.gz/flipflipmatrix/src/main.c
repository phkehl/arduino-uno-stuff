// $Id: main.c 2644 2013-09-22 20:59:22Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/main.c $
/*!

    \file
    \brief flipflipMATRIX main() (see \ref MAIN)

    - Copyright (c) 2012-2013 Philippe Kehl < phkehl at gmail dot com >

    \defgroup MAIN main() program
    @{
*/

#include <util/delay.h>
#include <avr/wdt.h>

#include "stdstuff.h"

#include "debug.h"
#include "tasks.h"
#include "matrix.h"


//! mirror of the MCU status register
uint8_t MCUSR_mirror __attribute__((section (".noinit")));

//! initialisation routine, called very early
void get_mcusr(void) __attribute__((naked)) __attribute__((section(".init3")));
void get_mcusr(void)
{
    // save and clear the MCU status register
    MCUSR_mirror = MCUSR;
    MCUSR = 0;
    // disable watchdog early
    wdt_disable();
}


//! the main routine
/*!
    The main routine. Where it all starts.
    \return  never actually returns..
*/
int main(void)
{
    // wait for SLIC, BT to power up, and don't mess with the ISP programmer
    _delay_ms(250);

    // enable the watchdog (we'll reconfigure it later)
    wdt_enable(WDTO_4S); // 4s

    // setup debugging facility
    debugInit();

    // check reset reason
    if (MCUSR_mirror & BIT(WDRF))
    {
        DEBUG("watchdog system reset");
    }
    if (MCUSR_mirror & BIT(BORF))
    {
        DEBUG("brown-out reset");
    }
    if (MCUSR_mirror & BIT(EXTRF))
    {
        DEBUG("external reset");
    }
    if (MCUSR_mirror & BIT(PORF))
    {
        DEBUG("power-on reset");
    }
    FLUSH;

    // say hello
    NOTICE("***** " PROJECT " (" BUILDREV " " BUILDDATE ") *****");
    NOTICE("(c) 2013 Philippe Kehl < phkehl at gmail dot com >");
    FLUSH;

    // initialise LED matrix
    matrixInit();

    // start scheduler and tasks
    tasksInit(); // this never returns

    return 0;
}


//@}
// eof
