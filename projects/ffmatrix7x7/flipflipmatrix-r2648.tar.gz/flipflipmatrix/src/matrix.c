// $Id: matrix.c 2648 2013-09-26 21:21:38Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/matrix.c $
/*!
    \file
    \brief flipflipMATRIX matrix task (see \ref MATRIX)

    - Copyright (c) 2013 Philippe Kehl < phkehl at gmail dot com >

    - portions based on work by others, namely:
      - sProgPlasma() colour changing plasma thingy
      - countless Youtube videos

    \addtogroup MATRIX
    @{
*/

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <util/delay.h>

#include "stdstuff.h"
#include "matrix.h"

#include "atomthreads.h"
#include "debug.h"

#if !defined(__AVR_ATmega328P__) && !defined(__AVR_ATmega168__)
#  error Missing configuration for your target device!
#endif





/* ***** low-level matrix frame buffer access ******************************** */

#define N_X (7)         //!< number of columns
#define N_Y (7)         //!< number of rows
#define N_XY (N_X*N_Y)  //!< number of pixels

//! matrix pixel colour components
typedef enum RGBHSV_e
{
    _R_ = 1, //!< red
    _G_ = 2, //!< green
    _B_ = 0, //!< blue

    _H_ = 0, //!< hue
    _S_ = 1, //!< saturation
    _V_ = 2, //!< value

    N_RGBHSV = 3 //!< number of components
} RGBHSV_t;

//! matrix frame memory definition
typedef union MATRIX_s
{
    //! access components by coordinates
    U1 yx[ N_Y ][ N_X ][ N_RGBHSV ];
    //! access components by index
    U1 ix[ N_Y * N_X ][ N_RGBHSV ];
    //! linear raw data access
    U1 raw[ N_Y * N_X * N_RGBHSV ];
} MATRIX_t;

//! matrix frame memory
static MATRIX_t sMatrix;

//! matrix (hardware and software) initialisation
/*!
    Initialises the matrix hardware and software.
*/
void matrixInit(void);

//! the matrix task (the matrix "main()")
/*!
    The matrix task. This shall never return.

    \param data  task paramete (unused)
*/
void matrixTask(U4 data);

//! flush the matrix
/*!
    Flushes the matrix framebuffer to the display (the LEDs).

    \param isHSV  #TRUE if values in buffre are in HSV (in which case they're
                  transformed to RGB before flushing, which will take a bit
                  longer, #FALSE if RGB values
*/
static void sMatrixFlush(IN const L isHSV);

//! clear the matrix buffer
/*!
    Clears the matrix buffer (all black/off).
*/
static void sMatrixClear(void);

//! set all pixels to RGB colour
/*
    Sets all pixels to the given RGB colour.

    \param r  red value
    \param g  green value
    \param b  blue value
*/
static void sMatrixSetAllRGB(IN const U1 r, IN const U1 g, IN const U1 b);

//! set all pixel to HSV colour
/*
    Sets all pixels to the given HSV colour.

    \param h  hue value
    \param s  saturation value
    \param v  value ("brightness")
*/
static void sMatrixSetAllHSV(IN const U1 h, IN const U1 s, IN const U1 v);

//! set pixel at index to RGB colour
/*
    Sets the pixel at the given index to the given RGB colour.

    \param ix  index into matrix (0 <= ix < N_XY)
    \param r   red value
    \param g   green value
    \param b   blue value
*/
static void sMatrixSetIxRGB(IN const U1 ix, IN const U1 r, IN const U1 g, IN const U1 b);

//! set pixel at index to HSV colour
/*
    Sets the pixel at the given index to the given HSV colour.

    \param ix  index into matrix (0 <= ix < N_XY)
    \param h   hue value
    \param s   saturation value
    \param v   value ("brightness")
*/
static void sMatrixSetIxHSV(IN const U1 ix, IN const U1 h, IN const U1 s, IN const U1 v);

//! set pixel at coordinate to RGB colour
/*
    Sets the pixel at the given coordinates to the given RGB colour.

    \param x   x coordinate (0 <= x < N_X)
    \param y   x coordinate (0 <= y < N_Y)
    \param r   red value
    \param g   green value
    \param b   blue value
*/
static void sMatrixSetXYRGB(IN const U1 x, IN const U1 y, IN const U1 r, IN const U1 g, IN const U1 b);

//! set pixel at coordinate to HSV colour
/*
    Sets the pixel at the given coordinates to the given RGB colour.

    \param x   x coordinate (0 <= x < N_X)
    \param y   x coordinate (0 <= y < N_Y)
    \param h   hue value
    \param s   saturation value
    \param v   value ("brightness")
*/
static void sMatrixSetXYHSV(IN const U1 x, IN const U1 y, IN const U1 h, IN const U1 s, IN const U1 v);

//! mix pixel at coordinate with RGB colour
/*
    Mixes the pixel at the given coordinates with the given RGB colour.

    \param x   x coordinate (0 <= x < N_X)
    \param y   x coordinate (0 <= y < N_Y)
    \param r   red value
    \param g   green value
    \param b   blue value
*/
static void sMatrixMixXYRGB(IN const U1 x, IN const U1 y, IN const U1 r, IN const U1 g, IN const U1 b);

//! mix pixel at coordinate with HSV colour
/*
    Mixes the pixel at the given coordinates with the given HSV colour.

    \param x   x coordinate (0 <= x < N_X)
    \param y   x coordinate (0 <= y < N_Y)
    \param h   hue value
    \param s   saturation value
    \param v   value ("brightness")
*/
static void sMatrixMixXYHSV(IN const U1 x, IN const U1 y, IN const U1 h, IN const U1 s, IN const U1 v);


/* ***** user input parameters *********************************************** */

//! potentiometer readings
typedef struct POT_s
{
    U1 gr; //!< grey pot
    U1 bk; //!< black pot
} POT_t;

//! potentiometer readings
static POT_t sPots;

//! update potentiometer readings
static void sPotUpdate(void);


/* ***** funky utility functions ********************************************* */

//! update potentiometer readings
static void sPotUpdate(void);

//! scale pot reading to given range
static I1 sPotScaleI1(IN const U1 potVal, IN const I1 min, IN const I1 max);

//! scale pot reading to given range
static U1 sPotScaleU1(IN const U1 potVal, IN const U1 min, IN const U1 max);

//! scale pot reading to given range
static U4 sPotScaleU4(IN const U1 potVal, IN const U4 min, IN const U4 max);


/* ***** matrix program implementatins *************************************** */

//! "kaa" program
/*
    Runs the "kaa" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgKaa(IN const L init);

//! "rainbow" program
/*
    Runs the "rainbow" program.

    Based on code from ... \todo hmmm.. where was that again?

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgRainbow(IN const L init);

//! "diag(onal)" program
/*
    Runs the "diag(onal)" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgDiag(IN const L init);

//! "plasma" program
/*
    Runs the "plasma" program.

    The formulae are based on code floating the internet in various code (goolf
    "colorduino", "shiftbrite", et al.). While the original source is never
    properly referenced it all seems to be GPL v2 and attributed to:
    copyright (c) 2011 Sam C. Lin, 2009 Ben Combee, 2009 Ken Corey, 2008
    Windell H. Oskay

    \todo find original reference for this

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgPlasma(IN const L init);

//! "stars" program
/*
    Runs the "stars" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgStars(IN const L init);

//! "rain" program
/*
    Runs the "rain" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgRain(IN const L init);

//! "test" program
/*
    Runs the "test" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgTest(IN const L init);

//! "sprites" program
/*
    Runs the "sprites" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgSprites(IN const L init);

//! "strobo" program
/*
    Runs the "strobo" program.

    \param init  run the initalisation, #TRUE on first call, #FALSE thereafter
*/
static U4 sProgStrobo(IN const L init);

//! matrix program function pointer
typedef U4 (*PROGFUNC_t)(const L);

//! programs info
typedef struct PROGINFO_s
{
    char       name[22];  //!< program name
    PROGFUNC_t func;      //!< program function
    U4         autoTime;  //!< how long to play in auto mode (0 = don't use in auto-mode)
} PROGINFO_t;

//! available progams to play
static const PROGINFO_t sProgInfo[] PROGMEM =
{
    { "plasma",      sProgPlasma,      60000 },
    { "kaa",         sProgKaa,         60000 },
    { "rain",        sProgRain,        60000 },
    { "rainbow",     sProgRainbow,     60000 },
    { "stars",       sProgStars,       60000 },
    { "diag",        sProgDiag,        60000 },
    { "test",        sProgTest,            0 },
    { "sprites",     sProgSprites,         0 },
    { "strobo",      sProgStrobo,          0 }
};

#define AUTOPLAY_DEFAULT FALSE

//! switch program request pending?
static volatile L sSwitchProg;

//! ISR to handle button presses to switch to the next mode
ISR(INT0_vect)
{
    sSwitchProg = TRUE;
}

typedef struct SPRITE_s
{
    I1 w;   //!< width [px]
    I1 h;   //!< height [px]
    I1 p;   //!< padding [px]
    I1 x;   //!< current x position [2^-4px]
    I1 y;   //!< current y position [2^-4px]
    I1 dx;  //!< delta x positon per move [2^-4px]
    I1 dy;  //!< delta y positon per move [2^-4px]
    U1 hue; //!< hue value
    U1 value[6][6]; //!< value per pixel
} SPRITE_t;

typedef struct PROGSTATE_SPRITES_s
{
    SPRITE_t sprites[3];
} PROGSTATE_SPRITES_t;

typedef struct PROGSTATE_DIAG_s
{
    U1 hueOffset;
} PROGSTATE_DIAG_t;

typedef struct PROGSTATE_PLASMA_s
{
    I4 paletteShift;
    U1 plasma[N_X][N_Y];
} PROGSTATE_PLASMA_t;

typedef struct PROGSTATE_KAA_s
{
    U1 offset;
} PROGSTATE_KAA_t;

typedef struct PROGSTATE_RAINBOW_s
{
    I j;
} PROGSTATE_RAINBOW_t;

typedef struct PROGSTAR_s
{
    U1 ix;
    U1 hue;
    U1 val;
    U1 valMax;
    I1 speed;
} PROGSTAR_t;

typedef struct PROGSTATE_STARS_s
{
    PROGSTAR_t stars[N_XY/5];
} PROGSTATE_STARS_t;

typedef struct PROGRAIN_s
{
    I1 pos;
    U1 hue;
    U1 len;
} PROGRAIN_t;

typedef struct PROGSTATE_RAIN_s
{
    PROGRAIN_t drops[N_X];
    I1 f;
    U1 n;
} PROGSTATE_RAIN_t;

typedef union PROGSTATE_u
{
    PROGSTATE_SPRITES_t sprites;
    PROGSTATE_DIAG_t    diag;
    PROGSTATE_PLASMA_t  plasma;
    PROGSTATE_KAA_t     kaa;
    PROGSTATE_RAINBOW_t rainbow;
    PROGSTATE_STARS_t   stars;
    PROGSTATE_RAIN_t    rain;
} PROGSTATE_t;

static PROGSTATE_t sProgState;


/* ***** implementation (matrix and utility functions) *********************** */

void matrixInit(void)
{
    /* ***** hardware SPI *************************************************** */

    SETBITS(DDRB, BIT(PB5) | BIT(PB3) | BIT(PB2)); // SCK, MOSI, SS (?!)
    SPCR = BIT(SPE) | BIT(MSTR); // enable, master mode
    //SPSR = 0;          SPCR |= BIT(SPR1) | BIT(SPR0); // f/128  125kHz
    //SPSR = 0;          SPCR |= BIT(SPR1);             // f/64   250kHz
    //SPSR = BIT(SPI2X); SPCR |= BIT(SPR1);             // f/32   500kHz
    //SPSR = 0;          SPCR |=             BIT(SPR0); // f/16   1MHz
    //SPSR = BIT(SPI2X); SPCR |=             BIT(SPR0); // f/8    2MHz
    SPSR = 0;          SPCR |= 0;                     // f/4    4MHz
    //SPSR = BIT(SPI2X); SPCR |= 0;                     // f/2    8MHz


    /* ***** flush LED ****************************************************** */

    SETBITS(DDRC, BIT(PC5));


    /* ***** pots *********************************************************** */

    // set all pins (ADC4..3) as input (required?)
    CLEARBITS(DDRC, BIT(PC4) | BIT(PC3));

    // Digital Input Disable Register
    // - disable digital input buffers on all ADC pins
    DIDR0 = BIT(PC4) | BIT(PC3);

    // ADC Multiplexer Selection Register
    // - AREF (internal Vref turned off)
    ADMUX = 0;

    // ADC Control and Status Register A
    // - ADC clock: 16MHz / 128 = 128kHz
    // - ADC enabled
    // - ADC start conversion
    ADCSRA = BIT(ADPS2) | BIT(ADPS1) | BIT(ADPS0);
    ADCSRA |= BIT(ADEN);
    ADCSRA |= BIT(ADSC);

    // ADC Control and Status Register B
    // - free running
    // - no input disabled
    ADCSRB = 0 | 0;

    // update data
    sPotUpdate();


    /* ***** button ********************************************************* */

    CLEARBITS(DDRD, BIT(PD2));   // enable INT0 pin input
    SETBITS(PORTD, BIT(PD2));    // enable pull-up
    EICRA = BIT(ISC01);          // falling-edge triggers interrupts
    EIMSK = BIT(INT0);           // enable interrupts


    /* ***** mode LEDs ****************************************************** */

    // mode LEDs
    SETBITS(  DDRD,  BIT(PD5) | BIT(PD6) | BIT(PD7));
    CLEARBITS(PORTD, BIT(PD5) | BIT(PD6) | BIT(PD7));
    // auto LED
    SETBITS(  DDRB,  BIT(PB0));
    CLEARBITS(PORTB, BIT(PB0));


    /* ***** initialise state *********************************************** */

    // clear all
    sMatrixClear();
    sMatrixFlush(FALSE);

    DEBUG("matrix: init"); FLUSH;
}

typedef enum TASKSTATE_e
{
    TASKSTATE_INIT,        //!< initialise program
    TASKSTATE_PLAY,        //!< play program
    TASKSTATE_NEXT,        //!< select next program to play
    TASKSTATE_CLEAR        //!< do transition to next program
} TASKSTATE_t;


void matrixTask(U4 data)
{
    // current task state
    TASKSTATE_t taskState = TASKSTATE_NEXT;

    // are we in auto-play mode?
    L autoPlay = AUTOPLAY_DEFAULT;

    // timeout for auto-play
    U4 autoTime = 0;
    U4 autoDelay = 0;

    // currently selected program
    I1 progIx = -1;
    PROGFUNC_t progFunc = NULL;

    UNUSED(data);

    while (ENDLESS)
    {
        // default delay
        U4 delay = 10;

        // update potentiometer readings
        sPotUpdate();

        switch (taskState)
        {

            /* ***** select next program ************************************* */

            case TASKSTATE_NEXT:
                while (ENDLESS)
                {
                    // try next
                    progIx++;

                    // go into auto-mode?
                    if ( (autoPlay == FALSE) && (progIx >= (I1)NUMOF(sProgInfo)))
                    {
                        autoPlay = TRUE;
                    }

                    // wrap
                    progIx %= NUMOF(sProgInfo);

                    // got a suitable program?
                    if (autoPlay)
                    {
                        autoTime = (U4)pgm_read_word(&sProgInfo[progIx].autoTime);
                        if (autoTime > 0)
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                // set program function
                progFunc = (PROGFUNC_t)pgm_read_word(&sProgInfo[progIx].func);
                autoDelay = 0;

                // go clear..
                taskState = TASKSTATE_CLEAR;
                break;


            /* ***** initialise program ************************************** */

            case TASKSTATE_CLEAR:

                // clear display
                //sProgClear(progIx + 1);

                // go initialise..
                taskState = TASKSTATE_INIT;
                break;



            /* ***** initialise program ************************************** */

            case TASKSTATE_INIT:
                DEBUG("matrix: prog=%S (%d) %S %lu",
                      sProgInfo[progIx].name, progIx + 1,
                      autoPlay ? PSTR("auto") : PSTR("user"),
                      autoPlay ? autoTime : 0);

                // set prog LEDs
                PORTD = (PORTD & ~(BIT(PD5) | BIT(PD6) | BIT(PD7)))
                    | (((progIx + 1) << PD5) & (BIT(PD5) | BIT(PD6) | BIT(PD7)));

                // set auto-play LED
                if (autoPlay)
                {
                    SETBITS(PORTB, BIT(PB0));
                }
                else
                {
                    CLEARBITS(PORTB, BIT(PB0));
                }

                // run program initialisation
                delay = progFunc(TRUE);

                // go play..
                taskState = TASKSTATE_PLAY;
                break;


            /* ***** play program ******************************************** */

            case TASKSTATE_PLAY:

                // run program (render next frame)
                delay = progFunc(FALSE);

                // switch to next program?
                if (sSwitchProg) // user pressed the button
                {
                    taskState = TASKSTATE_NEXT;
                    sSwitchProg = FALSE;
                    // coming from auto-play -> start at the first program
                    if (autoPlay)
                    {
                        progIx = -1;
                        autoPlay = FALSE;
                    }
                }
                if (autoPlay && (autoDelay >= autoTime)) // time's up for this program
                {
                    taskState = TASKSTATE_NEXT;
                }

                break;
        }

        // delay (and yield)
        autoDelay += delay;
        atomTimerDelay(MS2TICKS(delay));

    }
}


static void sMatrixFlush(IN const L isHSV)
{
    // disable scheduler
    CS_ENTER;

    // debug signal
    SETBITS(PORTC, BIT(PC5));

    // convert to HSV first
    if (isHSV)
    {
        U n = N_XY;
        while (n--)
        {
#if 0
            // à la Wikipedia, but integer math, 2.07ms
            U1 h = sMatrix.ix[n][_H_];
            U1 s = sMatrix.ix[n][_S_];
            U1 v = sMatrix.ix[n][_V_];
            U1 r = 0, g = 0, b = 0; // achromatic (grey) if s == 0
            if (s)
            {
                U1 i = h / 43; // hue sector, 256/6=42.67 -> 0..5
                U1 f = h % 43; // offset into hue sector -> 0..43
                U1 m = v - (U1)(((U2)v * (U2)s) >> 8); // lower limit v*(1-s)
                U2 q = ((U2)v * ((((U2)42*(U2)255) - ((U2)s * (U2)f)) / (U2)42)) / (U2)256; // v * (1.0 - s * f)
                U2 t = ((U2)v * ((((U2)42*(U2)255) - ((U2)s * ((U2)42 - (U2)f))) / (U2)42)) / (U2)256; // v * (1.0 - s * (1.0 - f))
                switch (i)
                {
                    case 0: r = v; g = t; b = m; break;
                    case 1: r = q; g = v; b = m; break;
                    case 2: r = m; g = v; b = t; break;
                    case 3: r = m; g = q; b = v; break;
                    case 4: r = t; g = m; b = v; break;
                    case 5: r = v; g = m; b = q; break;
                }
            }
            sMatrix.ix[n][_R_] = r;
            sMatrix.ix[n][_G_] = g;
            sMatrix.ix[n][_B_] = b;
#else
            // based on code from Nenad Milosevic (http://mbed.org/forum/mbed/topic/1251),
            // slightly improved, inaccurate!, 0.42ms
            U2 h = sMatrix.ix[n][_H_] * 6;
            U2 s = sMatrix.ix[n][_S_];
            U2 v = sMatrix.ix[n][_V_] + 1;
            U2 r = 0, g = 0, b = 0; // achromatic (grey) if s == 0
            if (h < 256)                                       // s=255:
            {
                r = 255;
                g = (((U2)256*(U2)255) - s * (255 - h)) >> 8;  // 0..255
                b = 255 - s;
            }
            else if (h < 511)
            {
                r = (((U2)256*(U2)255) - s * (h - 255)) >> 8;  // 254..0
                g = 255;
                b = 255 - s;
            }
            else if (h < 766)
            {
                r = 255 - s;
                g = 255;
                b = (((U2)256*(U2)255) - s * (766 - h)) >> 8;  // 0..254
            }
            else if (h < 1021)
            {
                r = 255 - s;
                g = (((U2)256*(U2)255) - s * (h - 765)) >> 8;  // 254..0
                b = 255;
            }
            else if (h < 1276)
            {
                r = (((U2)256*(U2)255) - s * (1276 - h)) >> 8; // 0..254
                g = 255 - s;
                b = 255;
            }
            else // h < 1531
            {
                r = 255;
                g = 255 - s;
                b = (((U2)256*(U2)255) - s * (h - 1275)) >> 8; // 254..0
            }

            sMatrix.ix[n][_R_] = (v * r) >> 8;
            sMatrix.ix[n][_G_] = (v * g) >> 8;
            sMatrix.ix[n][_B_] = (v * b) >> 8;
#endif
        }
    }

    //CS_ENTER;

    // debug signal
    CLEARBITS(PORTC, BIT(PC5));
    SETBITS(PORTC, BIT(PC5));

    // send all data (this takes approx. 0.165ms at 8MHz SPI speed)
    U n = sizeof(sMatrix.raw);
    U1 *pData = sMatrix.raw;
    while (n--)
    {
        SPDR = *pData++;
        loop_until_bit_is_set(SPSR, SPIF); // delay between bytes: 1.08us
        //while (!(SPSR & BIT(SPIF)));     // delay between bytes: 1.25us
        //__asm__ volatile ("nop");        // delay between bytes: 0.167us
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
        //__asm__ volatile ("nop");
    }

    // latch data
    _delay_us(500);

    // debug signal
    CLEARBITS(PORTC, BIT(PC5));

    // enable scheduler
    CS_LEAVE;
}


static inline void sMatrixClear(void)
{
    memset(sMatrix.raw, 0, sizeof(sMatrix.raw));
}


static void sMatrixSetAllRGB(IN const U1 r, IN const U1 g, IN const U1 b)
{
    U1 ix = N_XY;
    while (ix--)
    {
        sMatrix.ix[ix][_R_] = r;
        sMatrix.ix[ix][_G_] = g;
        sMatrix.ix[ix][_B_] = b;
    }
}


static void sMatrixSetAllHSV(IN const U1 h, IN const U1 s, IN const U1 v)
{
    U1 ix = N_XY;
    while (ix--)
    {
        sMatrix.ix[ix][_H_] = h;
        sMatrix.ix[ix][_S_] = s;
        sMatrix.ix[ix][_V_] = v;
    }
}


static inline void sMatrixSetIxRGB(IN const U1 ix, IN const U1 r, IN const U1 g, IN const U1 b)
{
    sMatrix.ix[ix][_R_] = r;
    sMatrix.ix[ix][_G_] = g;
    sMatrix.ix[ix][_B_] = b;
}


static inline void sMatrixSetIxHSV(IN const U1 ix, IN const U1 h, IN const U1 s, IN const U1 v)
{
    sMatrix.ix[ix][_H_] = h;
    sMatrix.ix[ix][_S_] = s;
    sMatrix.ix[ix][_V_] = v;
}


static inline void sMatrixSetXYRGB(IN const U1 x, IN const U1 y, IN const U1 r, IN const U1 g, IN const U1 b)
{
    sMatrix.yx[y][x][_R_] = r;
    sMatrix.yx[y][x][_G_] = g;
    sMatrix.yx[y][x][_B_] = b;
}


static inline void sMatrixSetXYHSV(IN const U1 x, IN const U1 y, IN const U1 h, IN const U1 s, IN const U1 v)
{
    sMatrix.yx[y][x][_H_] = h;
    sMatrix.yx[y][x][_S_] = s;
    sMatrix.yx[y][x][_V_] = v;
}


static inline void sMatrixMixXYRGB(IN const U1 x, IN const U1 y, IN const U1 r, IN const U1 g, IN const U1 b)
{
    if (sMatrix.yx[y][x][_R_])
    {
        sMatrix.yx[y][x][_R_] = ((U2)sMatrix.yx[y][x][_R_] + (U2)r) >> 1;
    }
    else
    {
        sMatrix.yx[y][x][_R_] = r;
    }
    if (sMatrix.yx[y][x][_G_])
    {
        sMatrix.yx[y][x][_G_] = ((U2)sMatrix.yx[y][x][_G_] + (U2)g) >> 1;
    }
    else
    {
        sMatrix.yx[y][x][_G_] = g;
    }
    if (sMatrix.yx[y][x][_B_])
    {
        sMatrix.yx[y][x][_B_] = ((U2)sMatrix.yx[y][x][_B_] + (U2)b) >> 1;
    }
    else
    {
        sMatrix.yx[y][x][_B_] = b;
    }
}

static inline void sMatrixMixXYHSV(IN const U1 x, IN const U1 y, IN const U1 h, IN const U1 s, IN const U1 v)
{
    if (sMatrix.yx[y][x][_H_])
    {
        sMatrix.yx[y][x][_H_] = ((U2)sMatrix.yx[y][x][_H_] + (U2)h) >> 1;
    }
    else
    {
        sMatrix.yx[y][x][_H_] = h;
    }
    if (sMatrix.yx[y][x][_S_])
    {
        sMatrix.yx[y][x][_S_] = ((U2)sMatrix.yx[y][x][_S_] + (U2)s) >> 1;
    }
    else
    {
        sMatrix.yx[y][x][_S_] = s;
    }
    if (sMatrix.yx[y][x][_V_])
    {
        sMatrix.yx[y][x][_V_] = ((U2)sMatrix.yx[y][x][_V_] + (U2)v) >> 1;
    }
    else
    {
        sMatrix.yx[y][x][_V_] = v;
    }
}


static void sPotUpdate(void)
{
    // ADC0: enable, start conversion, wait conversion, store value
    //ADMUX = BIT(ADLAR) | 0;
    //ADCSRA |= BIT(ADSC);
    //loop_until_bit_is_clear(ADCSRA, ADSC);
    //sPots.rd = ADCH;

    // ADC1: enable, start conversion, wait conversion, store value
    //ADMUX = BIT(ADLAR) | BIT(MUX0);
    //ADCSRA |= BIT(ADSC);
    //loop_until_bit_is_clear(ADCSRA, ADSC);
    //sPots.gn = ADCH;

    // ADC2: enable, start conversion, wait conversion, store value
    //ADMUX = BIT(ADLAR) | BIT(MUX1);
    //ADCSRA |= BIT(ADSC);
    //loop_until_bit_is_clear(ADCSRA, ADSC);
    //sPots.bl = ADCH;

    // ADC3: enable, start conversion, wait conversion, store value
    ADMUX = BIT(ADLAR) | BIT(MUX0) | BIT(MUX1);
    ADCSRA |= BIT(ADSC);
    loop_until_bit_is_clear(ADCSRA, ADSC);
    sPots.bk = ADCH;

    // ADC4: enable, start conversion, wait conversion, store value
    ADMUX = BIT(ADLAR) | BIT(MUX2);
    ADCSRA |= BIT(ADSC);
    loop_until_bit_is_clear(ADCSRA, ADSC);
    sPots.gr = ADCH;
}


static I1 sPotScaleI1(IN const U1 potVal, IN const I1 min, IN const I1 max)
{
    return (I1)( (I2)( ((I2)potVal * (I2)((I2)max - (I2)min + (I2)1)) >> 8) + (I2)min );
}

static U1 sPotScaleU1(IN const U1 potVal, IN const U1 min, IN const U1 max)
{
    return (U1)( ((U2)potVal * (U2)(max - min + 1)) >> 8) + min;
}

static U4 sPotScaleU4(IN const U1 potVal, IN const U4 min, IN const U4 max)
{
    return ((potVal * (max - min + 1)) >> 8) + min;
}


/* ***** Kaa program implementation ****************************************** */

static U4 sProgKaa(IN const L init)
{

    if (init)
    {
        sProgState.kaa.offset = 0;
    }
    else
    {
        sProgState.kaa.offset++;
    }

    sMatrixClear();

    // calculate stuff
    const I x0 = N_X / 2;
    const I y0 = N_X / 2;
    const U1 hueMax = 255/3; //sPots.bk;
    const U1 s = 255;
    const U1 v = sPotScaleU1(sPots.gr, 10, 255);

    I dx = x0 + 1;
    while (dx--)
    {
        I dy = y0 + 1;
        while (dy--)
        {
            const U1 hue = (U1)((I2)(((I2)dx*(I2)dx) + ((I2)dy*(I2)dy))
               * ((I2)hueMax) / (((I2)x0*(I2)x0) + ((I2)y0*(I2)y0))) + sProgState.kaa.offset;
            //DEBUG("%2i %2i %2i %2i %3u -> %2i %2i   %2i %2i  %2i %2i  %2i %2i",
            //      dx, dy, x0, y0, hue,
            //      x0 + dx, dy, x0 - dx, dy, dx, y0 + dy, dx, y0 - dy);
            //atomTimerDelay(10);
            sMatrixSetXYHSV(x0 + dx, y0 + dy, hue, s, v);
            sMatrixSetXYHSV(x0 - dx, y0 + dy, hue, s, v);
            sMatrixSetXYHSV(x0 + dx, y0 - dy, hue, s, v);
            sMatrixSetXYHSV(x0 - dx, y0 - dy, hue, s, v);
        }
    }

    sMatrixFlush(TRUE);

    return sPotScaleU4(sPots.bk, 10, 1000);
}


/* ***** rainbow program implementation ************************************** */

static U4 sProgRainbow(IN const L init)
{
    if (init)
    {
        sProgState.rainbow.j = 0;
    }
    else
    {
        sProgState.rainbow.j++;
    }

    //for (I j = 0; j < 256; j++)
    {
        for (I ix = 0; ix < N_XY; ix++)
        {
            //U1 wheel = (
            //    (sPots.gr < 128) ?
            //    (ix + j) :
            //    ((ix * 256 / N_XY) + j)
            //    ) /* % 255*/;
            //U1 wheel = (ix + j);
            U1 wheel = ((ix * 256 / N_XY) + sProgState.rainbow.j);

            U1 r, g, b;
            if (wheel < 85)
            {
                r = wheel * 3;
                g = 255 - (wheel * 3);
                b = 0;
            }
            else if (wheel < 170)
            {
                wheel -= 85;
                r = 255 - (wheel * 3);
                g = 0;
                b = wheel * 3;
            }
            else
            {
                wheel -= 170;
                r = 0;
                g = wheel * 3;
                b = 255 - (wheel * 3);
            }

            sMatrixSetIxRGB(ix, r, g, b);
        }
    }

    sMatrixFlush(FALSE);

    return sPotScaleU4(sPots.bk, 10, 500);
}


/* ***** diag(onal) program implementation *********************************** */

static U4 sProgDiag(IN const L init)
{
    const U1 v = sPotScaleU4(sPots.gr, 0, 255);

    if (init)
    {
        sProgState.diag.hueOffset = 0;
    }
    else
    {
        sProgState.diag.hueOffset++;
    }

    for (U1 y = 0; y < N_Y; y++)
    {
        for (U1 x = 0; x < N_X; x++)
        {
            const U1 hMax = 200;
            const U1 hOff = sProgState.diag.hueOffset;
            const U1 h = hOff + (U1)(U2)(  (  ((U2)(x*x)   +   (U2)(y*y)) * (U2)hMax ) /
                                           ( (U2)(N_X*N_X) + (U2)(N_Y*N_Y)           )  );
            sMatrixSetXYHSV(x, y, h, 255, v);
        }
    }

    sMatrixFlush(TRUE);

    return sPotScaleU4(sPots.bk, 10, 1000);
}


/* ***** plasma program implementation *************************************** */

// based on [1, dist()]
static R4 sDist(IN const R4 a, IN const R4 b, IN const R4 c, IN const R4 d)
{
    const R4 cma = c - a;
    const R4 dmb = d - b;
    return sqrtf( (cma * cma) + (dmb * dmb) );
}

static U4 sProgPlasma(IN const L init)
{
    const U1 v = sPotScaleU1(sPots.gr, 1, 255);

    if (init)
    {
        // based on [1, setup()]
        sProgState.plasma.paletteShift = 128000;
        for (U1 y = 0; y < N_Y; y++)
        {
            for (U1 x = 0; x < N_X; x++)
            {
                sProgState.plasma.plasma[x][y] = (U1)(
                    256.0f + ( 256.0f * sinf( (R4)x * (16.0f / 24.0f) ) ) +
                    256.0f + ( 256.0f * sinf( (R4)y * (8.0f / 16.0f) ) )
                    ) / 2;
            }
        }
    }

    for (U1 y = 0; y < N_Y; y++)
    {
        for (U1 x = 0; x < N_X; x++)
        {
            // based on [1, plasma_morph()]
            const R4 value =
                sinf( sDist((x + sProgState.plasma.paletteShift), y, 128.0f, 128.0) * (1.0f / 8.0f)) +
                sinf( sDist(x, y, 64.0f, 64.0f) * (1.0f / 8.0f) ) +
                sinf( sDist(x, y + (sProgState.plasma.paletteShift / 7), 192.0f, 64.0f) * (1.0f / 7.0f) ) +
                sinf( sDist(x, y, 192.0f, 100.0f) * (1.0 / 8.0) );
            const U1 h = (U1)((U4)(value * 128.0) & 0xff);
            sMatrixSetXYHSV(x, y, h, 255, v);
        }
    }
    sProgState.plasma.paletteShift--;

    sMatrixFlush(TRUE);

    return sPotScaleU4(sPots.bk, 10, 1000);
}


/* ***** stars program implementation **************************************** */

static U4 sProgStars(IN const L init)
{
    PROGSTAR_t *stars = sProgState.stars.stars;
    const U1  nStars = NUMOF(sProgState.stars.stars);
    const U1 vBase = sPotScaleU1(sPots.gr, 1, 100);
    const U1 vMin = 3;

    // initialise
    if (init)
    {
        srand( sPotScaleU4(sPots.bk, 0x0000, 0xffff) );
        memset(&sProgState.stars, 0, sizeof(sProgState.stars));
        sMatrixClear();
        for (U1 ix = 0; ix < N_XY; ix++)
        {
            sMatrixSetIxHSV(ix, rand() & 0xff, 255, vMin);
        }
        sMatrixFlush(TRUE);
    }

    // create stars as needed
    for (U1 starIx = 0; starIx < nStars; starIx++)
    {
        if (stars[starIx].speed)
        {
            continue;
        }
        stars[starIx].ix = rand() % N_XY;
        L uniq;
        do
        {
            uniq = TRUE;
            stars[starIx].ix = rand() % N_XY;
            if (starIx > 0)
            {
                U1 testIx = starIx;
                while (testIx--)
                {
                    if (stars[testIx].ix == stars[starIx].ix)
                    {
                        uniq = FALSE;
                        break;
                    }
                }
            }
        } while (uniq == FALSE);
        stars[starIx].hue    = rand() & 0xff;
        stars[starIx].speed  = (rand() % 5) + 3;
        stars[starIx].valMax = vBase + (rand() % vBase);
        stars[starIx].val    = 1;
        //DEBUG("starIx=%u/%u ix=%u hue=%u speed=%i valMax=%u", starIx, nStars,
        //      stars[starIx].ix, stars[starIx].hue, stars[starIx].speed, stars[starIx].valMax);
        //atomTimerDelay( MS2TICKS(50) );
    }


    // render and decay
    for (U1 starIx = 0; starIx < nStars; starIx++)
    {
        // convert current HSV to RGB
        const U1 h = stars[starIx].hue;
        const U1 s = 255;
        const U1 v = stars[starIx].val;
        U1 r = 0, g = 0, b = 0; // achromatic (grey) if s == 0
        U1 i = h / 43; // hue sector, 256/6=42.67 -> 0..5
        U1 f = h % 43; // offset into hue sector -> 0..43
        U1 m = v - (U1)(((U2)v * (U2)s) >> 8); // lower limit v*(1-s)
        U2 q = ((U2)v * ((((U2)42*(U2)255) - ((U2)s * (U2)f)) / (U2)42)) / (U2)256; // v * (1.0 - s * f)
        U2 t = ((U2)v * ((((U2)42*(U2)255) - ((U2)s * ((U2)42 - (U2)f))) / (U2)42)) / (U2)256; // v * (1.0 - s * (1.0 - f))
        switch (i)
        {
            case 0: r = v; g = t; b = m; break;
            case 1: r = q; g = v; b = m; break;
            case 2: r = m; g = v; b = t; break;
            case 3: r = m; g = q; b = v; break;
            case 4: r = t; g = m; b = v; break;
            case 5: r = v; g = m; b = q; break;
        }
        sMatrixSetIxRGB(stars[starIx].ix, r, g, b);

        // calculate next
        const I2 val = stars[starIx].val + stars[starIx].speed;
        if (stars[starIx].speed > 0) // fade in
        {
            if (val <= (I2)stars[starIx].valMax)
            {
                stars[starIx].val = (U1)val;
            }
            else
            {
                stars[starIx].speed = -stars[starIx].speed;
            }
        }
        else // fade out
        {
            if (val >= vMin)
            {
                stars[starIx].val = (U1)val;
            }
            else
            {
                stars[starIx].val = vMin;
                stars[starIx].speed = 0;
            }
        }
    }
    sMatrixFlush(FALSE);

    return sPotScaleU4(sPots.bk, 10, 1000);
}


/* ***** rain program implementation ***************************************** */

static U4 sProgRain(IN const L init)
{
    PROGRAIN_t *drops = sProgState.rain.drops;
    const U1 nX = MIN( NUMOF(sProgState.rain.drops), N_X );

    if (init)
    {
        srand( sPotScaleU4(sPots.bk, 0x0000, 0xffff) );
        memset(&sProgState.rain, 0, sizeof(sProgState.rain));
    }

    if (sProgState.rain.f <= 0)
    {
        sProgState.rain.f = 100;
    }

    sMatrixClear();

    const U1 maxLen = 6;  // max length of the drop
    const U1 ds = 30;  // saturation steps
    const U1 dv = 20;  // value steps
    const U1 v0 = sPotScaleU1(sPots.gr, ((maxLen-1) * dv) + 1, 255);

    L new = FALSE;

    // check all columns
    for (U1 x = 0; x < nX; x++)
    {
        // animate
        if (drops[x].pos)
        {
            const U1 h = drops[x].hue;
            const I1 p1 = drops[x].pos;
            const I1 p0 = p1 - drops[x].len + 1;
            U1 s = 255 - (drops[x].len * ds);
            U1 v = v0 - (drops[x].len * dv);
            for (I1 p = p0; p <= p1; p++)
            {
                s += ds;
                v += dv;
                const I1 y = N_Y - p;
                if ( (y >= 0) && (y < N_Y) )
                {
                    //DEBUG("%2i %2i %3u %3u %3u/%3u", p1, y, h, s, v, v0);
                    sMatrixSetXYHSV(x, (U1)y, h, s, v);
                }

            }

            //sMatrixSetXYHSV(x, N_Y - drops[x].pos, drops[x].hue, 255, drops[x].val);
            if (p0 > (N_Y - 1))
            {
                drops[x].pos = 0;
            }
            else
            {
                drops[x].pos++;
            }
        }
        // maybe create a new raindrop
        else
        {
            if ((rand() % sProgState.rain.f) == 0)
            {
                drops[x].pos = 1;
                drops[x].hue = rand();
                drops[x].len = (rand() % maxLen) + 1;
                sProgState.rain.n++;
                //DEBUG("new %u %u f=%u n=%u", drops[x].hue, drops[x].len, sProgState.rain.f, sProgState.rain.n);
            }
        }
    }

    sMatrixFlush(TRUE);

    // reduce frequency
    if (sProgState.rain.n >= 5)
    {
        sProgState.rain.n = 0;
        if (sProgState.rain.f > 50)
        {
            sProgState.rain.f -= 10;
        }
        else if (sProgState.rain.f > 20)
        {
            sProgState.rain.f -= 5;
        }
        else
        {
            sProgState.rain.f -= 1;
        }
    }


    return sPotScaleU4(sPots.bk, 25, 1000);
}


/* ***** test program implementation ***************************************** */

static U4 sProgTest(IN const L init)
{
    UNUSED(init);
    const U1 h = sPotScaleU4(sPots.gr, 0, 255);
    const U1 v = sPotScaleU4(sPots.bk, 0, 255);
    sMatrixSetAllHSV(h, 255, v);
    sMatrixFlush(TRUE);
    return 20;
}


/* ***** strobo program implementation *************************************** */

static U4 sProgStrobo(IN const L init)
{
    UNUSED(init);

    const U1 brightness = sPots.gr;
    const U4 delay = sPotScaleU4(sPots.bk, 10, 500);

    sMatrixSetAllRGB(brightness, brightness, brightness);
    sMatrixFlush(FALSE);

    atomTimerDelay( MS2TICKS(delay) );

    sMatrixSetAllRGB(0, 0, 0);
    sMatrixFlush(FALSE);

    return delay;
}


/* ***** sprites program implementation ************************************** */

static void sRenderSpriteMixHSV(IN const SPRITE_t *pkSprite)
{
    I1 x0 = pkSprite->x >> 4;
    I1 y0 = pkSprite->y >> 4;

    //DEBUG("%i %i", x0, y0);

    I1 sx = pkSprite->w;
    while (sx--)
    {
        I1 px = x0 + sx;
        if ( (px < 0) || (px >= N_X) )
        {
            continue;
        }
        I1 sy = pkSprite->h;
        while (sy--)
        {
            I1 py = y0 + sy;
            if ( (py < 0) || (py >= N_Y) )
            {
                continue;
            }

            sMatrixMixXYHSV(px, py, pkSprite->hue, 255, pkSprite->value[sy][sx]);
        }
    }
}

static void sMoveSprite(INOUT SPRITE_t *pSprite)
{
    // move
    pSprite->x += pSprite->dx;
    pSprite->y += pSprite->dy;

    // bounce at edges, considering padding
    const I1 p = pSprite->p;

    const I1 w = pSprite->w;
    const I1 x = pSprite->x >> 4;
    if ( (x > (N_X - p)) || (x < -w + p) )
    {
        pSprite->dx = -pSprite->dx;
        pSprite->x += pSprite->dx;
    }

    const I1 h = pSprite->h;
    const I1 y = pSprite->y >> 4;
    if ( (y > (N_Y - p)) || (y < -h + p) )
    {
        pSprite->dy = -pSprite->dy;
        pSprite->y += pSprite->dy;
    }
}

static const SPRITE_t skSprites[] PROGMEM =
{
#if 0
    {
        3, 4, -1, 0, 0, 0, // w, h, x, y, dx, dy
        10, // hue
        { // values
            {  20,  75,  20 },
            {  75, 255,  75 },
            {  75, 255,  75 },
            {  20,  75,  20 }
        }
    },
    {
        4, 3, 3, 3, 0, 0,
        90,
        {
            {  20,  75,  75,  20 },
            {  75, 255, 255,  75 },
            {  20,  75,  75,  20 }
        }
    }
#endif
#if 0
    // w, h, p, x, y, dx, dy, hue, values
    { 1, 1, 1, 0<<4, 0<<4, 1<<4, 1<<2,  10, { { 255, 255 }, { 255, 255 } } },
    { 3, 1, 1, 3<<4, 2<<4, 1<<2, 0<<4, 100, { { 255, 255, 255 } } },
    { 1, 3, 0, 3<<4, 4<<4, 0<<4, 1<<4, 200, { { 255 }, { 255 }, { 255 } } }
#endif
    {
        5, 5, 5,
        1<<4, 1<<4,
        1<<4, 1<<3,
        0,
        {
            {  10,  75,  75,  75,  10 },
            {  75, 150, 150, 150,  75 },
            {  75, 150, 255, 150,  75 },
            {  75, 150, 150, 150,  75 },
            {  10,  75,  75,  75,  10 }
        }
    },
    {
        5, 5, 2,
        1<<4, 1<<4,
        -1<<4, 1<<3,
        60,
        {
            {  10,  75,  75,  75,  10 },
            {  75, 150, 150, 150,  75 },
            {  75, 150, 255, 150,  75 },
            {  75, 150, 150, 150,  75 },
            {  10,  75,  75,  75,  10 }
        }
    },
    {
        5, 5, 2,
        1<<4, 1<<4,
        1<<4, -1<<3,
        120,
        {
            {  10,  75,  75,  75,  10 },
            {  75, 150, 150, 150,  75 },
            {  75, 150, 255, 150,  75 },
            {  75, 150, 150, 150,  75 },
            {  10,  75,  75,  75,  10 }
        }
    },
    {
        5, 5, 2,
        1<<4, 1<<4,
        -1<<4, -1<<3,
        180,
        {
            {  10,  75,  75,  75,  10 },
            {  75, 150, 150, 150,  75 },
            {  75, 150, 255, 150,  75 },
            {  75, 150, 150, 150,  75 },
            {  10,  75,  75,  75,  10 }
        }
    }

};


static U4 sProgSprites(IN const L init)
{
    const U nSprites = MIN( NUMOF(sProgState.sprites.sprites), NUMOF(skSprites) );

    // load sprites
    if (init)
    {
        DEBUG("load %u sprites", nSprites);
        U ix = nSprites;
        while (ix--)
        {
            memcpy_P(&sProgState.sprites.sprites[ix], &skSprites[ix], sizeof(SPRITE_t));
        }
    }

    // render sprites
    sMatrixClear();


    U ix = nSprites;
    while (ix--)
    {
        sRenderSpriteMixHSV(&sProgState.sprites.sprites[ix]);
    }

    sMatrixFlush(TRUE);

    // update sprite positions

    ix = nSprites;
    while (ix--)
    {
        sMoveSprite(&sProgState.sprites.sprites[ix]);
    }

    return sPotScaleU4(sPots.bk, 10, 1000);
}


/* ***** unused code ********************************************************* */

#if 0
// https://hg.stremlau.eu/repo/HSVLamp/file/c4c90eade3c2/main.c
// http://read.pudn.com/downloads120/sourcecode/embed/512546/AVR_Meag8_contorl_R_G_B_LED/firmware/rgbCtrl.c__.htm
static void sHSV2RGB(IN const U1 h, IN const U1 s, IN const U1 v,
                     OUT U1 *r, OUT U1 *g, OUT U1 *b)
{
    // achromatic (grey)
    if (s == 0)
    {
        *r = *g = *b = v;
    }
    else
    {
        U1 i = h / 43; // hue sector, 256/6=42.67 -> 0..5
        U1 f = h % 43; // offset into hue sector -> 0..43
        U1 m = v - (U1)(((U2)v * (U2)s) >> 8); // lower limit v*(1-s)
        U2 q = ((U2)v * ((((U2)42*(U2)255) - ((U2)s * (U2)f)) / (U2)42)) / (U2)256; // v * (1.0 - s * f)
        U2 t = ((U2)v * ((((U2)42*(U2)255) - ((U2)s * ((U2)42 - (U2)f))) / (U2)42)) / (U2)256; // v * (1.0 - s * (1.0 - f))
        switch (i)
        {
            case 0: *r = v; *g = t; *b = m; break;
            case 1: *r = q; *g = v; *b = m; break;
            case 2: *r = m; *g = v; *b = t; break;
            case 3: *r = m; *g = q; *b = v; break;
            case 4: *r = t; *g = m; *b = v; break;
            case 5: *r = v; *g = m; *b = q; break;
        }
    }
    //DEBUG("hsv: %3u %3u %3u  rgb: %3u %3u %3u", h, s, v, r, g, b);
}
#endif

#if 0
static void sHSV2RGBf(IN const U1 h, IN const U1 s, IN const U1 v,
                      OUT U1 *r, OUT U1 *g, OUT U1 *b)

{
    R4 _h = (R4)h * (359.9999999f/256.0f); // [0..360[
    R4 _v = (R4)v * (1.0f/255.0f);   // [0..1]
    R4 _s = (R4)s * (1.0f/255.0f);   // [0..1]

    R4 C = _v * _s;    // C (chroma)
    R4 Hd = _h / 60.0f; // H'
    R4 X = C * (1.0f - fabsf( fmodf(Hd, 2.0f) - 1.0));

    R4 _r, _g, _b;

    if      (Hd < 1.0) { _r = C;     _g = X;     _b = 0.0f; }
    else if (Hd < 2.0) { _r = X;     _g = C;     _b = 0.0f; }
    else if (Hd < 3.0) { _r = 0.0f;  _g = C;     _b = X; }
    else if (Hd < 4.0) { _r = 0.0f;  _g = X;     _b = C; }
    else if (Hd < 5.0) { _r = X;     _g = 0.0f;  _b = C; }
    else if (Hd < 6.0) { _r = C;     _g = 0.0f;  _b = X; }

    R4 m = _v - C;

    _r += m;
    _g += m;
    _b += m;

    *r = _r * 255.0f;
    *g = _g * 255.0f;
    *b = _b * 255.0f;
    //DEBUG("%hf %hf %hf / %hf %hf %hf -> %hf %hf %hf", _h, _s, _v,  C, Hd, X, _r, _g, _b);
}
#endif

#if 0
static void sProgClear(IN const U1 progNr)
{
    //DEBUG("clear start");
    if (0)
    {
        U1 ix;
        for (ix = 0; ix < N_XY; ix++)
        {
            sMatrixSetIxRGB(ix, 255, 255, 255);
            sMatrixFlush(FALSE);
            atomTimerDelay(MS2TICKS(5));
        }
        for (ix = 0; ix < N_XY; ix++)
        {
            sMatrixSetIxRGB(ix, 0, 0, 0);
            sMatrixFlush(FALSE);
            atomTimerDelay(MS2TICKS(5));
        }
    }
    if (0)
    {
        U1 y;
        for (y = 0; y < (N_Y + 2); y++)
        {
            U1 x;
            for (x = 0; x < N_X; x++)
            {
                if (y < N_Y)
                {
                    sMatrixSetXYRGB(x, y, 255, 255, 255);
                }

                if ( (y > 0) && (y < (N_Y + 1)) )
                {
                    sMatrixSetXYRGB(x, y - 1, 100, 100, 100);
                }
                if ( (y > 1) && (y < (N_Y + 2)) )
                {
                    sMatrixSetXYRGB(x, y - 2, 0, 0, 0);
                }
            }

            sMatrixFlush(FALSE);
            atomTimerDelay(MS2TICKS(40));
        }
    }
    if (1)
    {
        U1 dx = (N_X / 2) + 1;
        U1 dy = (N_Y / 2) + 1;
        do
        {
            U1 x, y;
            if (dx > 0)
            {
                dx--;
            }
            if (dy > 0)
            {
                dy--;
            }

            //DEBUG("clear %u %u -> %u %u / %u %u", dx, dy, (N_X / 2) - dx, (N_X / 2) + dx, (N_Y / 2) - dy, (N_Y / 2) + dy);
            for (x = (N_X / 2) - dx; x <= (N_X / 2) + dx; x++)
            {
                sMatrixSetXYRGB(x, (N_Y / 2) + dy, 0, 0, 0);
                sMatrixSetXYRGB(x, (N_Y / 2) - dy, 0, 0, 0);
            }
            for (y = (N_Y / 2) - dy; y <= (N_Y / 2) + dy; y++)
            {
                sMatrixSetXYRGB((N_X / 2) + dx, y, 0, 0, 0);
                sMatrixSetXYRGB((N_X / 2) - dx, y, 0, 0, 0);
            }

            sMatrixFlush(FALSE);
            atomTimerDelay(MS2TICKS(750 / N_X));
        }
        while ( (dx > 0) || (dy > 0) );

    }

    if (0)
    {
        U1 x;
        for (x = 0; x < progNr; x++)
        {
            sMatrixSetXYHSV(x, 0, 0, 0, sPotScaleI1(sPots.gr, 10, 150));
        }
        sMatrixFlush(TRUE);
        atomTimerDelay(MS2TICKS(250));
    }


    //DEBUG("clear done");
}
#endif

#if 0
// stolen from http://www.mikrocontroller.net/articles/AVR_Arithmetik, modified
U1 sqrtU2 (U2 q)
{
    U1 r, mask;
    U1 i = (8 * 1) - 1;
    r = mask = 1 << i;
    for (; i > 0; i--)
    {
        mask >>= 1;
        if (q < ((U2)r*(U2)r))
        {
            r -= mask;
        }
        else
        {
            r += mask;
        }
    }
    if (q < ((U2)r*(U2)r))
    {
        r -= 1;
    }
    return r;
}
#endif

#if 0
static U4 sProgPlasma(IN const L init)
{
    if (init)
    {
        sProgState.plasma.i1 = 0;
        sProgState.plasma.i2 = 0;
    }

    // hight map range
    const U1 z1min = 1;
    const U1 z1max = 100;

    const U1 z2min = 1;
    const U1 z2max = 100;

    // circle centre and radius
    const R4 a = (R4)(N_X - 1) / 2.0f;
    const R4 b = (R4)(N_Y - 1) / 2.0f;
    //const R4 r = (R4)(MIN(N_X, N_Y) - 1) * (1.0f/2.0f);
    const R4 r = (R4)(MIN(N_X, N_Y) - 1) * (1.0f/3.0f);

    // steps per revolution
    const U1 i1max = 32;

    const U1 i2max = 20;

    // calculate offset of the height map
    const R4 t1 = (R4)sProgState.plasma.i1 * (2.0f * (R4)M_PI / (R4)i1max); // phase
    const U1 x1 = (U1)roundf( a + (r * cosf(t1)) );
    const U1 y1 = (U1)roundf( b + (r * sinf(t1)) );

    const R4 t2 = (R4)sProgState.plasma.i2 * (2.0f * (R4)M_PI / (R4)i2max); // phase
    const U1 x2 = (U1)roundf( a + (r * cosf(t2)) );
    const U1 y2 = (U1)roundf( b + (r * sinf(t2)) );

#if 0
    sMatrixClear();
    sMatrixMixXYRGB(x1, y1, 255, 0, 0);
    sMatrixMixXYRGB(x2, y2, 0, 255, 0);
    sMatrixFlush(FALSE);


#else
    const U1 X = (2 * N_X) - 1;
    const U1 Y = (2 * N_Y) - 1;

    // fill heights
    for (U1 x = 0; x < N_X; x++)
    {
        for (U1 y = 0; y < N_Y; y++)
        {
            //const U1 dx1 = x + x1;
            //const U1 dy1 = y + y1;
            //const U1 z1 = z1min + (U1)(U2)(  ((U2)(dx1*dx1) + (U2)(dy1*dy1)) * (U2)z1max /
            //                                 ( (U2)(X*X)  +  (U2)(Y*Y) )              );

            const U1 dx1 = (x < x1 ? x1 - x : x - x1);
            const U1 dy1 = (y < y1 ? y1 - y : y - y1);
            const U1 z1 = z1min + (U1)(U2)(  (U2)(z1max) / sqrtU2( (U2)(dx1*dx1) + (U2)(dy1*dy1) + 1 ) );

            const U1 dx2 = (x < x2 ? x2 - x : x - x2);
            const U1 dy2 = (y < y2 ? y2 - y : y - y2);
            const U1 z2 = z2min + (U1)(U2)(  (U2)(z2max) / sqrtU2( (U2)(dx2*dx2) + (U2)(dy2*dy2) + 1 ) );

            //sMatrixSetXYHSV(x, y, 1, 255, z2);
            //sMatrixSetXYHSV(x, y, z1, 255, z1+z2);

            //sMatrixSetXYHSV(x, y, z1 + z2, 255, z1 + z2);
            sMatrixSetXYHSV(x, y, (z1 + z2) >> 3, 255, z2);
        }
    }
    sMatrixFlush(TRUE);
#endif

    // next step
    sProgState.plasma.i1++;
    sProgState.plasma.i1 %= i1max;
    sProgState.plasma.i2--;
    sProgState.plasma.i2 %= i2max;

    return sPotScaleU4(sPots.bk, 10, 1000);
}
#endif

/* ************************************************************************** */
//@}
// eof

