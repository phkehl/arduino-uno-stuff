// $Id: matrix.h 2509 2012-11-08 21:44:57Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/matrix.h $
/*!
    \file
    \brief flipflipMATRIX matrix task (see \ref MATRIX)

    - Copyright (c) 2012 Philippe Kehl < phkehl at gmail dot com >

    \defgroup MATRIX LED Matrix
    @{
*/

#ifndef __MATRIX_H__
#define __MATRIX_H__ //!< multiple inclusion guard

#include "stdstuff.h"


void matrixInit(void);

void matrixTask(U4 data);


#endif // __FFP_H__

//@}
// eof
