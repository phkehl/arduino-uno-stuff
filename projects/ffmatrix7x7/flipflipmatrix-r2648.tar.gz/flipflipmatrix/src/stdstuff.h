/*!
    \file
    \brief flipflipMATRIX standard types, macros, and other stuff (see \ref STDSTUFF)

    - Copyright (c) 2011-2012 Philippe Kehl < flipflip at gmx dot net >

    \defgroup STDSTUFF Standard types, macros and other stuff
    @{
*/
// $Id: stdstuff.h 2515 2012-11-11 17:21:43Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/stdstuff.h $

#ifndef __STDSTUFF_H__
#define __STDSTUFF_H__ //!< multiple inclusion guard

#include <inttypes.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/io.h>


//! \name data types
//@{
typedef int8_t            I1; //!<  8 bit signed
typedef uint8_t           U1; //!<  8 bit unsigned
typedef int16_t           I2; //!< 16 bit signed
typedef uint16_t          U2; //!< 16 bit unsigned
typedef int32_t           I4; //!< 32 bit signed
typedef uint32_t          U4; //!< 32 bit unsigned
typedef float             R4; //!< 32 bit float
typedef char              CH; //!< 8 bit character
typedef int               I;  //!< signed integer
typedef unsigned int      U;  //!< unsigned integer
typedef U1                L1; //!< boolean
typedef U1                L;  //!< boolean
//typedef double            R8; //!< 64 bit float (not available!)
//@}


//! \name handy macros
//@{
#define BIT(bit) (1<<(bit))   //!< bit
#define UNUSED(foo) (void)foo //!< unused variable
#define TRUE  1               //!< boolean true
#define FALSE 0               //!< boolean false
#define SETBITS(port, bits)    port |= (bits)   //!< sets the bits
#define CLEARBITS(port, bits)  port &= ~(bits)  //!< clears the bits
#define TOGGLEBITS(port, bits) port ^= (bits)   //!< toggles the bits
#define NUMOF(x) (sizeof(x)/sizeof(*(x)))       //!< number of elements in vector
#define ENDLESS TRUE          //!< for endless while loops
#define FALLTHROUGH           //!< switch fall-through marker
#define ___PADNAME(x) __pad##x    //!< padding name (used by __PAD())
#define __PADNAME(x) __PADNAME(x) //!< padding name (used by __PAD())
#define __PAD(n) U1 __PADNAME(__LINE__)[n]  //!< struct padding macro
#define __PADFILL { 0 }           //!< to fill const padding
#define MIN(a, b)  ((b) < (a) ? (b) : (a)) //!< smaller value of a and b
#define MAX(a, b)  ((b) > (a) ? (b) : (a)) //!< bigger value of a and b
//@}


//! \name critical sections
//@{
//! enter a critical section, asserting that interrupts are off
#define CS_ENTER { const U1 _sreg = SREG; cli();
//! leave a critical section, re-enabling the interrupts if necessary
#define CS_LEAVE SREG = _sreg; }
//@}


//! \name docu macros
//@{
#define IN     //!< null macro to mark a input parameter
#define OUT    //!< null macro to mark a output parameter
#define INOUT  //!< null macro to mark a input and output parameter
//@}

#endif // __STDSTUFF_H__

//@}
// eof
