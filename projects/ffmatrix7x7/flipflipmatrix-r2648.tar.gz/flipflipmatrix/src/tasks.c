// $Id: tasks.c 2646 2013-09-23 22:38:45Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/tasks.c $
/*!
    \file
    \brief flipflipMATRIX tasks (see \ref TASKS)

    - Copyright (c) 2011-2013 Philippe Kehl < phkehl at gmail dot com >

    \addtogroup TASKS
    @{
*/


#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <avr/wdt.h>
#include <stdio.h>
#include <string.h>

#include "stdstuff.h"
#include "atomthreads.h"
#include "tasks.h"
#include "debug.h"
#include "matrix.h"


#if !defined(__AVR_ATmega328P__) && !defined(__AVR_ATmega168__)
#  error Missing configuration for your target device!
#endif


static uint8_t  sTasksIdleStack[64];    //!< the idle thread's stack

static ATOM_TCB sTasksDebugTCB;         //!< the debug thread's TCB
static uint8_t  sTasksDebugStack[128];  //!< the debug thread's stack

static ATOM_TCB sTasksMonTCB;           //!< the monitor thread's TCB
static uint8_t  sTasksMonStack[192];    //!< the monitor thread's stack
static void sTasksMonTask(U4 deleay);   //!< the monitor task

static ATOM_TCB sTasksMatrixTCB;        //!< the matrix thread's TCB
static uint8_t  sTasksMatrixStack[192]; //!< the matrix thread's stack


typedef void (*TASKFUNC_t)(uint32_t);

//! list of tasks
typedef struct TASK_s
{
    char       name[4];     //!< task name
    U1         priority;    //!< priority (0 = highest, 254 = lowest)
    U1        *pStack;      //!< pointer to the stack
    U4         stackSize;   //!< stack size
    ATOM_TCB  *pTCB;        //!< pointer to the TCB
    TASKFUNC_t function;    //!< pointer to the task function
    U4         argument;    //!< task function argument
} TASK_t;

static const TASK_t sTasksList[] PROGMEM =
{
    { "mon",  20, sTasksMonStack,    sizeof(sTasksMonStack),    &sTasksMonTCB,    sTasksMonTask, SYSTICKS_HZ },
    { "dbg",  10, sTasksDebugStack,  sizeof(sTasksDebugStack),  &sTasksDebugTCB,  debugTask,     0 },
    { "mtx",  50, sTasksMatrixStack, sizeof(sTasksMatrixStack), &sTasksMatrixTCB, matrixTask,    0 }
};

extern ATOM_TCB idle_tcb;

static void sTasksMonTask(U4 delay)
{
    // arm watchdog (we'll be running every second)
    wdt_enable(WDTO_2S); // 2s

    U4 cnt = 0;
#ifdef ATOM_STACK_CHECKING
    CH str[14 * NUMOF(sTasksList)] = "";
#endif
    while (ENDLESS)
    {
#ifdef ATOM_STACK_CHECKING
        CH *pStr = str;
        L dump = (cnt % 10) == 0 ? TRUE : FALSE;
#endif

        // get monitor values
        const U4 msss = atomTimeGet(); // [ms] since startup
        cnt++;

        // feed the watchdog
        wdt_reset();

#ifdef ATOM_STACK_CHECKING
        *pStr = '\0';
        // get stack size
        for (U ix = 0; ix <= NUMOF(sTasksList); ix++)
        {
            U4 used, free;
            const TASK_t *pkTask = &sTasksList[ix];
            ATOM_TCB *pTCB = ix == NUMOF(sTasksList) ? atomGetIdleTCB() : (ATOM_TCB *)pgm_read_word(&pkTask->pTCB);
            const U1 status = atomThreadStackCheck(pTCB, &used, &free);
            if (status == ATOM_OK) // always true..
            {
                // ouch! possible stack overflow
                if (free == 0)
                {
                    CS_ENTER;
                    ERROR("stack %-7S %3d %3d", pkTask->name, (int)used, (int)free); FLUSH;
                    // trigger software reset
                    wdt_enable(WDTO_30MS); while (ENDLESS);
                    CS_LEAVE;
                }
                // debug dump values
                else if (dump)
                {
                    snprintf_P(pStr, 14, PSTR(" %S %d %d"),
                               ix == NUMOF(sTasksList) ? PSTR("idl") : pkTask->name, (int)used, (int)free);
                    pStr = &str[strlen(str)];
                }
            }
        }
        if (dump)
        {
            DEBUG("mon %lu %lu%s", msss, cnt, str);
#else
            DEBUG("mon %lu %lu", msss, cnt);
#endif
        }

        // yield and sleep ~1s (align to top-of-second)
        atomTimerDelay(delay - (atomTimeGet() % delay));
    }

}


void tasksInit(void)
{
    // reuse part of the idle thread's stack for the stack required
    // during this startup function.
    //SP = (int)sTasksIdleStack[sizeof(sTasksIdleStack)/2 - 1]; // FIXME: why?
    //int freeRam () {
    //    extern int __heap_start, *__brkval;
    //    int v;
    //    return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval);
    //}


#ifdef ATOM_DEBUG_TICKS
    SETBITS(DDRD, BIT(PD3));
#endif

    U1 status = atomOSInit(sTasksIdleStack, sizeof(sTasksIdleStack), TRUE);
    if (status == ATOM_OK)
    {
        //DEBUG("tasks: init"); FLUSH;

        // setup and enable the system tick timer
        TCCR0A = /*BIT(COM0A0)             // toggle OC0A on compare match
               |*/ BIT(WGM01);             // clear timer on compare match (CTC)
#if (SYSTICKS_HZ == 1000)
        TCCR0B = BIT(CS00) | BIT(CS01);  // prescale clk/64
        OCR0A  = (F_CPU / 64 / 1000);    // 1ms ticks on output compare register A (= 250 @ 16MHz)
#elif (SYSTICKS_HZ == 100)
        TCCR0B = BIT(CS00) | BIT(CS02);  // prescale clk/1024
        OCR0A  = (F_CPU / 1024 / 100);   // 10ms ticks on output compare register A (= 156.25 @ 16MHz)
#else
#  error No configuration for your choice of SYSTICKS_HZ
#endif
        //SETBITS(DDRD, BIT(PD6));         // configure OC0A pin as output
        TCNT0  = 0;                      // timer/counter0 register
        TIFR0  = 0;                      // timer/counter0 interrupt flag register
        TIMSK0 = BIT(OCIE0A);            // timer/counter0 output compare match A interrupt enable

        DEBUG("tasks: HZ=%u", SYSTICKS_HZ);
        while (debugFlush());

        // start tasks
        for (U ix = 0; ix < NUMOF(sTasksList); ix++)
        {
            const TASK_t *pkTask = &sTasksList[ix];
            ATOM_TCB  *pTCB      = (ATOM_TCB *)pgm_read_word(&pkTask->pTCB);
            const U1   priority  = (U1)        pgm_read_byte(&pkTask->priority);
            U1        *pStack    = (U1 *)      pgm_read_word(&pkTask->pStack);
            const U4   stackSize = (U4)        pgm_read_word(&pkTask->stackSize);
            TASKFUNC_t function  = (TASKFUNC_t)pgm_read_word(&pkTask->function);
            const U4   argument  = (U4)        pgm_read_word(&pkTask->argument);
            //DEBUG("%S -> %p %p %lu %p %lu", pkTask->name, pkTCB, pStack, stackSize, function, argument); FLUSH;

            status = atomThreadCreate(pTCB, priority, function, argument, pStack, stackSize, TRUE);
            if (status == ATOM_OK)
            {
                DEBUG("tasks: %S", pkTask->name); FLUSH;
            }
            else
            {
                ERROR("tasks: %S %u", pkTask->name, status); FLUSH;
            }
        }

        // start OS
        atomOSStart(); // this never returns
    }
    else
    {
        ERROR("tasks: init"); FLUSH;
    }
}

//! task tick routine, runs the scheduler
//ISR(TIMER0_COMPA_vect, ISR_NAKED)
ISR(TIMER0_COMPA_vect)
{
#ifdef ATOM_DEBUG_TICKS
    SETBITS(PORTD, BIT(PD3));
    CLEARBITS(PORTD, BIT(PD3));
    //TOGGLEBITS(PORTD, BIT(PD3));
#endif
    atomIntEnter();    // call the interrupt entry routine
    atomTimerTick();   // call the OS system tick handler
    atomIntExit(TRUE); // call the interrupt exit routine
}


//@}
// eof
