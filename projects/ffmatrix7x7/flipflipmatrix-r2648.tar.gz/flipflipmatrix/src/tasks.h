// $Id: tasks.h 2502 2012-11-04 22:49:35Z flip $
// $HeadURL: svn+ssh://fry/flipflipmatrix/src/tasks.h $
/*!
    \file
    \brief flipflipMATRIX tasks (see \ref TASKS)

    - Copyright (c) 2012 Philippe Kehl < phkehl at gmail dot com >

    \defgroup TASKS Tasks
    @{

    Tasks.
*/

#ifndef __TASKS_H__
#define __TASKS_H__ //!< multiple inclusion guard

#include "stdstuff.h"


//! initialise scheduler and start tasks
/*!
    Initialises the scheduler and starts the tasks. Configures and arms Timer0
    [AVR8271, 14.0, pp.107]. The OC0A pin will toggle 1 Hz.
*/
void tasksInit(void);


#endif // __TASKS_H__

//@}
// eof
