#!/usr/bin/perl
# $Id: debug.pl 2640 2013-09-18 23:02:50Z flip $
# $HeadURL: svn+ssh://fry/flipflipmatrix/tools/debug.pl $

use strict;
use warnings;
use Time::HiRes qw(time usleep);
use Device::SerialPort;

my $debug = 0;

my ($port, $br) = @ARGV;
die("Usage: $0 <port> <baudrate>") unless ($port && $br);
printf(STDERR "port=%s br=%i\n", $port, $br);

my $sp = Device::SerialPort->new($port);
$sp->baudrate($br);
$sp->databits(8);
$sp->parity('none');
$sp->stopbits(1);
$sp->handshake('none');
$sp->buffers(4096, 4096);
$sp->user_msg(0); # debugging
$sp->error_msg(0); # STFU
$sp->read_char_time(0);
$sp->read_const_time(0);
$sp->write_settings();
$sp->reset_error();
$sp->lookclear();
$sp->reset_error();

my $data = {};

my $ABORT = 0;
$SIG{INT} = sub { printf(STDERR "Got C-c. Aborting ASAP!\n"); $ABORT = 1; };
my $n = 0;
$|++;
while (!$ABORT)
{
    $sp->reset_error();
    my $data = $sp->input();

    if ($data)
    {
        if ($debug)
        {
            printf(STDERR "%05i: got %i bytes: %s\n", $n++, length($data),
                   join(' | ', map { my $b = $_;
                                     sprintf('0x%02x %08b [%c]', $b, $b,
                                             chr($b) =~ m/^[[:print:]]$/ ? $b : ord('?')) }
                   unpack('C*', $data)));
        }

        if ($data =~ m/\033\[2J/)
        {
            my $time = sprintf('%.3f', time());
            $data =~ s/\033\[2J/\n\033[1m***** $time *****\033[m\n/;
            #$data =~ s/\033\[2J/\033[2J\n***** $time *****\n/;
        }
        #elsif ($data =~ m/mon\s+(\d+)\s+(\d+)\s+(.*)/)
        #{
        #    my ($t, undef, $tasks) = ($1, $2, $3);
        #    while ($tasks =~ m/(\S+)\s+(\d+)\s+(\d+)/g)
        #    {
        #        my ($tsk, $used, $free, $total) = ($1, $2, $3, $2 + $3);
        #        $data->{$t}->{$tsk} = [ $used, $free ];
        #    }
        #}


        print($data);
    }
    else
    {
        usleep(50e3);
    }
}
$|--;

1;
__END__
